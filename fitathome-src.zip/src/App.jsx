import { Routes, Route, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Planner from './pages/Planner';
import PlanDetail from './pages/PlanDetail';
import Builder from './pages/Builder';
import Library from './pages/Library';
import Workout from './pages/Workout';
import Progress from './pages/Progress';
import CalendarPage from './pages/Calendar';
import BMI from './pages/BMI';
import Water from './pages/Water';
import Profile from './pages/Profile';
import NotFound from './pages/NotFound';

export default function App() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <Routes>
      {/* Full-screen workout player (no sidebar) */}
      <Route path="/workout/:planId" element={<Workout />} />
      <Route element={<Layout />}>
        <Route index element={<Dashboard />} />
        <Route path="planner" element={<Planner />} />
        <Route path="plans/:id" element={<PlanDetail />} />
        <Route path="builder" element={<Builder />} />
        <Route path="builder/:id" element={<Builder />} />
        <Route path="library" element={<Library />} />
        <Route path="progress" element={<Progress />} />
        <Route path="calendar" element={<CalendarPage />} />
        <Route path="bmi" element={<BMI />} />
        <Route path="water" element={<Water />} />
        <Route path="profile" element={<Profile />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
