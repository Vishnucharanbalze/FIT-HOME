// Browser-native audio cues (Web Audio API + Speech Synthesis). No files, no network.

let ctx = null;

function getCtx() {
  if (typeof window === 'undefined') return null;
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return null;
  if (!ctx) ctx = new AC();
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

/** Must be called from a user gesture once (e.g. the Start button) to unlock audio on mobile. */
export function unlockAudio() {
  const c = getCtx();
  if (!c) return;
  const o = c.createOscillator();
  const g = c.createGain();
  g.gain.value = 0;
  o.connect(g).connect(c.destination);
  o.start();
  o.stop(c.currentTime + 0.01);
}

function tone(freq, duration = 0.15, delay = 0, type = 'sine', volume = 0.25) {
  const c = getCtx();
  if (!c) return;
  const t0 = c.currentTime + delay;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t0);
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(volume, t0 + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
  o.connect(g).connect(c.destination);
  o.start(t0);
  o.stop(t0 + duration + 0.02);
}

export const sounds = {
  tick: () => tone(880, 0.12, 0, 'sine', 0.2),
  go: () => {
    tone(660, 0.12, 0, 'triangle', 0.3);
    tone(990, 0.25, 0.12, 'triangle', 0.3);
  },
  rest: () => {
    tone(523, 0.18, 0, 'sine', 0.25);
    tone(392, 0.3, 0.18, 'sine', 0.25);
  },
  finish: () => {
    [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.22, i * 0.15, 'triangle', 0.3));
  },
  click: () => tone(1200, 0.05, 0, 'square', 0.08),
};

export function speak(text) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  try {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 1.05;
    u.pitch = 1;
    window.speechSynthesis.speak(u);
  } catch {
    /* speech not available */
  }
}

/** Optional system notification (only if user granted permission). */
export function notify(title, body) {
  try {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, { body, icon: '/icons/icon-192.png' });
    }
  } catch {
    /* ignore */
  }
}

export function vibrate(pattern = 120) {
  try {
    navigator.vibrate?.(pattern);
  } catch {
    /* ignore */
  }
}
