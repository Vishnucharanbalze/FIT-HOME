import { EXERCISE_MAP } from '../data/exercises';

export const SECONDS_PER_REP = 3;
export const REST_MET = 1.5;

const LEVEL_SCALE = {
  Beginner: { sets: -1, amount: 0.7, rest: 1.3 },
  Intermediate: { sets: 0, amount: 1, rest: 1 },
  Advanced: { sets: 1, amount: 1.3, rest: 0.8 },
};

/** Adjust a plan's items for a fitness level (built-in plans are stored at Intermediate). */
export function scaleItems(items, level = 'Intermediate', baseLevel = 'Intermediate') {
  if (level === baseLevel) return items.map((i) => ({ ...i }));
  // Convert base -> intermediate -> target
  const from = LEVEL_SCALE[baseLevel] || LEVEL_SCALE.Intermediate;
  const to = LEVEL_SCALE[level] || LEVEL_SCALE.Intermediate;
  return items.map((i) => {
    const sets = Math.max(1, Math.min(6, i.sets - from.sets + to.sets));
    const k = to.amount / from.amount;
    const rest = Math.round(((i.rest || 0) / from.rest) * to.rest / 5) * 5;
    const out = { ...i, sets, rest };
    if (i.duration != null) out.duration = Math.max(10, Math.round((i.duration * k) / 5) * 5);
    if (i.reps != null) out.reps = Math.max(4, Math.round(i.reps * k));
    return out;
  });
}

const workSeconds = (it) => (it.duration != null ? it.duration : (it.reps || 0) * SECONDS_PER_REP);

/** Estimated total duration (seconds) of a list of plan items, including rests. */
export function estimateDuration(items) {
  let total = 0;
  items.forEach((it, idx) => {
    for (let s = 0; s < it.sets; s++) {
      total += workSeconds(it);
      const isLast = idx === items.length - 1 && s === it.sets - 1;
      if (!isLast) total += it.rest || 0;
    }
  });
  return total;
}

/** Calories = MET x weight(kg) x hours, summed for work and rest periods. */
export function estimateCalories(items, weightKg = 70) {
  let kcal = 0;
  items.forEach((it) => {
    const met = EXERCISE_MAP[it.exerciseId]?.met || 5;
    const work = workSeconds(it) * it.sets;
    const rest = (it.rest || 0) * it.sets;
    kcal += met * weightKg * (work / 3600) + REST_MET * weightKg * (rest / 3600);
  });
  return Math.round(kcal);
}

export function caloriesForWork(exerciseId, seconds, weightKg = 70) {
  const met = EXERCISE_MAP[exerciseId]?.met || 5;
  return met * weightKg * (seconds / 3600);
}

/**
 * Turn plan items into a flat list of player steps:
 * [prepare] -> work(set 1) -> rest -> work(set 2) -> ... -> work(last)
 */
export function buildSteps(items) {
  const steps = [];
  items.forEach((it, exIndex) => {
    const ex = EXERCISE_MAP[it.exerciseId];
    if (!ex) return;
    for (let set = 1; set <= it.sets; set++) {
      steps.push({
        kind: 'work',
        exIndex,
        exerciseId: it.exerciseId,
        set,
        totalSets: it.sets,
        mode: it.duration != null ? 'time' : 'reps',
        reps: it.reps,
        seconds: it.duration != null ? it.duration : Math.max(10, (it.reps || 0) * SECONDS_PER_REP),
      });
      const isLast = exIndex === items.length - 1 && set === it.sets;
      if (!isLast && (it.rest || 0) > 0) {
        steps.push({ kind: 'rest', exIndex, exerciseId: it.exerciseId, set, seconds: it.rest });
      }
    }
  });
  return steps;
}
