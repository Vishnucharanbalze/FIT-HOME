// Date helpers. All "day keys" are LOCAL dates in YYYY-MM-DD form.

const pad = (n) => String(n).padStart(2, '0');

export const toKey = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export const fromKey = (key) => {
  const [y, m, d] = key.split('-').map(Number);
  return new Date(y, m - 1, d);
};

export const todayKey = () => toKey(new Date());

export const addDays = (date, n) => {
  const d = new Date(date);
  d.setDate(d.getDate() + n);
  return d;
};

export const startOfDay = (date) => {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
};

/** Monday-based start of week */
export const startOfWeek = (date) => {
  const d = startOfDay(date);
  const day = (d.getDay() + 6) % 7; // Mon=0
  return addDays(d, -day);
};

export const startOfMonth = (date) => new Date(date.getFullYear(), date.getMonth(), 1);

export const daysInMonth = (date) => new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();

export const sameDay = (a, b) => toKey(a) === toKey(b);

export const formatDate = (date, opts = { day: 'numeric', month: 'short' }) =>
  new Date(date).toLocaleDateString(undefined, opts);

export const formatLongDate = (date) =>
  new Date(date).toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

export const formatTime = (date) =>
  new Date(date).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

/** 75 -> "1:15" */
export const clock = (sec) => {
  const s = Math.max(0, Math.ceil(sec));
  const m = Math.floor(s / 60);
  return `${m}:${pad(s % 60)}`;
};

/** 3725 -> "1h 2m", 300 -> "5 min" */
export const humanDuration = (sec) => {
  const m = Math.round(sec / 60);
  if (m < 60) return `${m} min`;
  const h = Math.floor(m / 60);
  return `${h}h ${m % 60}m`;
};

export const greeting = (d = new Date()) => {
  const h = d.getHours();
  if (h < 5) return 'Good night';
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
};
