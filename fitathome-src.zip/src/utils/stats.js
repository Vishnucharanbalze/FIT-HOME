import { BUILT_IN_PLANS } from '../data/plans';
import { EXERCISE_MAP } from '../data/exercises';
import { toKey, fromKey, addDays, startOfDay, startOfWeek, formatDate } from './date';

/** All plans: built-ins (with user's day overrides) + custom plans. */
export function getAllPlans(state) {
  const builtIns = BUILT_IN_PLANS.map((p) => ({
    ...p,
    builtIn: true,
    days: state.planDays?.[p.id] || p.days,
  }));
  return [...builtIns, ...(state.customPlans || [])];
}

export function getPlan(state, id) {
  return getAllPlans(state).find((p) => p.id === id);
}

export function scheduledPlans(state) {
  const ids = new Set(state.scheduledPlanIds || []);
  return getAllPlans(state).filter((p) => ids.has(p.id));
}

export function plansForDate(state, date) {
  const wd = new Date(date).getDay();
  return scheduledPlans(state).filter((p) => (p.days || []).includes(wd));
}

export function historyByDay(history = []) {
  const map = {};
  for (const h of history) {
    (map[h.dayKey] ||= []).push(h);
  }
  return map;
}

/**
 * Streak = number of workout days in a row, where unscheduled rest days do not
 * break the chain, but a missed scheduled day does. Today never breaks it.
 */
export function currentStreak(state) {
  const byDay = historyByDay(state.history);
  let streak = 0;
  let d = startOfDay(new Date());
  for (let i = 0; i < 400; i++) {
    const key = toKey(d);
    if (byDay[key]?.length) streak++;
    else if (i > 0 && plansForDate(state, d).length) break;
    d = addDays(d, -1);
  }
  return streak;
}

export function bestStreak(state) {
  const history = state.history || [];
  if (!history.length) return 0;
  const byDay = historyByDay(history);
  const first = fromKey(history.reduce((min, h) => (h.dayKey < min ? h.dayKey : min), history[0].dayKey));
  const today = startOfDay(new Date());
  let best = 0;
  let run = 0;
  for (let d = first; d <= today; d = addDays(d, 1)) {
    const key = toKey(d);
    if (byDay[key]?.length) {
      run++;
      best = Math.max(best, run);
    } else if (plansForDate(state, d).length && key !== toKey(today)) {
      run = 0;
    }
  }
  return best;
}

const sum = (arr, f) => arr.reduce((a, x) => a + (f(x) || 0), 0);

export function totals(history = []) {
  return {
    workouts: history.length,
    completed: history.filter((h) => h.completed).length,
    minutes: Math.round(sum(history, (h) => h.durationSec) / 60),
    calories: Math.round(sum(history, (h) => h.calories)),
  };
}

/** Per-day series for the last `days` days ending today. */
export function dailySeries(history = [], days = 7) {
  const byDay = historyByDay(history);
  const today = startOfDay(new Date());
  const out = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = addDays(today, -i);
    const list = byDay[toKey(d)] || [];
    out.push({
      key: toKey(d),
      label: days <= 7 ? d.toLocaleDateString(undefined, { weekday: 'short' }) : formatDate(d),
      minutes: Math.round(sum(list, (h) => h.durationSec) / 60),
      calories: Math.round(sum(list, (h) => h.calories)),
      workouts: list.length,
    });
  }
  return out;
}

/** Totals per Monday-based week for the last `weeks` weeks. */
export function weeklySeries(history = [], weeks = 8) {
  const thisWeek = startOfWeek(new Date());
  const out = [];
  for (let i = weeks - 1; i >= 0; i--) {
    const start = addDays(thisWeek, -7 * i);
    const end = addDays(start, 7);
    const list = history.filter((h) => {
      const d = fromKey(h.dayKey);
      return d >= start && d < end;
    });
    out.push({
      label: i === 0 ? 'This wk' : formatDate(start),
      workouts: list.length,
      minutes: Math.round(sum(list, (h) => h.durationSec) / 60),
      calories: Math.round(sum(list, (h) => h.calories)),
    });
  }
  return out;
}

export function monthlySeries(history = [], months = 6) {
  const now = new Date();
  const out = [];
  for (let i = months - 1; i >= 0; i--) {
    const m = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const prefix = toKey(m).slice(0, 7);
    const list = history.filter((h) => h.dayKey.startsWith(prefix));
    out.push({
      label: m.toLocaleDateString(undefined, { month: 'short' }),
      workouts: list.length,
      minutes: Math.round(sum(list, (h) => h.durationSec) / 60),
      calories: Math.round(sum(list, (h) => h.calories)),
      activeDays: new Set(list.map((h) => h.dayKey)).size,
    });
  }
  return out;
}

/** Scheduled vs completed for the current Monday-based week (up to today). */
export function weekCompletion(state) {
  const start = startOfWeek(new Date());
  const today = startOfDay(new Date());
  const byDay = historyByDay(state.history);
  let scheduled = 0;
  let done = 0;
  // Only days that have already happened count (today counts once it's done)
  for (let d = start; d <= today; d = addDays(d, 1)) {
    const isScheduled = plansForDate(state, d).length > 0;
    const did = (byDay[toKey(d)] || []).length > 0;
    if (toKey(d) === toKey(today) && !did) continue;
    if (isScheduled) {
      scheduled++;
      if (did) done++;
    } else if (did && d <= today) {
      // bonus workout on a rest day counts toward completion too
      scheduled++;
      done++;
    }
  }
  return { scheduled, done, pct: scheduled ? Math.round((done / scheduled) * 100) : 0 };
}

export function personalRecords(state) {
  const history = state.history || [];
  if (!history.length) return [];
  const longest = history.reduce((a, b) => (b.durationSec > a.durationSec ? b : a));
  const mostCal = history.reduce((a, b) => (b.calories > a.calories ? b : a));
  const weeks = weeklySeries(history, 52);
  const bestWeek = weeks.reduce((a, b) => (b.workouts > a.workouts ? b : a));
  const byDayCal = Object.entries(historyByDay(history)).map(([k, l]) => ({ k, c: sum(l, (h) => h.calories) }));
  const bestDay = byDayCal.reduce((a, b) => (b.c > a.c ? b : a));

  // Best single-session reps / hold per exercise
  const perEx = {};
  for (const h of history) {
    for (const e of h.exercises || []) {
      const ex = EXERCISE_MAP[e.exerciseId];
      if (!ex || !e.setsDone) continue;
      const value = e.duration != null ? e.duration : e.reps * e.setsDone;
      const unit = e.duration != null ? 'sec hold' : 'reps';
      if (!perEx[e.exerciseId] || value > perEx[e.exerciseId].value) {
        perEx[e.exerciseId] = { value, unit, dayKey: h.dayKey, name: ex.name };
      }
    }
  }
  const featured = ['push-ups', 'squats', 'plank', 'burpees', 'crunches', 'lunges', 'mountain-climbers', 'wall-sit']
    .filter((id) => perEx[id])
    .map((id) => ({ title: perEx[id].name, value: `${perEx[id].value} ${perEx[id].unit}`, date: perEx[id].dayKey, kind: 'exercise' }));

  return [
    { title: 'Longest workout', value: `${Math.round(longest.durationSec / 60)} min`, date: longest.dayKey, kind: 'time' },
    { title: 'Most calories (session)', value: `${Math.round(mostCal.calories)} kcal`, date: mostCal.dayKey, kind: 'fire' },
    { title: 'Best day', value: `${Math.round(bestDay.c)} kcal`, date: bestDay.k, kind: 'fire' },
    { title: 'Most workouts in a week', value: `${bestWeek.workouts} workouts`, date: null, kind: 'trophy' },
    { title: 'Best streak', value: `${bestStreak(state)} days`, date: null, kind: 'streak' },
    ...featured,
  ];
}

export function caloriesToday(history = []) {
  const k = toKey(new Date());
  return Math.round(sum(history.filter((h) => h.dayKey === k), (h) => h.calories));
}

export function minutesToday(history = []) {
  const k = toKey(new Date());
  return Math.round(sum(history.filter((h) => h.dayKey === k), (h) => h.durationSec) / 60);
}

export function bmiInfo(heightCm, weightKg) {
  const h = Number(heightCm) / 100;
  const w = Number(weightKg);
  if (!h || !w || h <= 0 || w <= 0) return null;
  const bmi = w / (h * h);
  let category;
  let color;
  if (bmi < 18.5) { category = 'Underweight'; color = '#5ee7ff'; }
  else if (bmi < 25) { category = 'Healthy weight'; color = '#3dff8b'; }
  else if (bmi < 30) { category = 'Overweight'; color = '#ffd23d'; }
  else { category = 'Obesity'; color = '#ff5e5e'; }
  const healthyMin = 18.5 * h * h;
  const healthyMax = 24.9 * h * h;
  return { bmi: Math.round(bmi * 10) / 10, category, color, healthyMin, healthyMax };
}
