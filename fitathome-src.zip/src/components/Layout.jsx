import { useState } from 'react';
import { NavLink, Outlet, useLocation, Link } from 'react-router-dom';
import {
  LayoutDashboard, ClipboardList, Dumbbell, Hammer, BarChart3, CalendarDays, Scale, Droplets, UserRound,
  Download, WifiOff, Grid2x2, Info, CheckCircle2, AlertTriangle, RotateCcw, X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useInstallPrompt, useOnline } from '../utils/pwa';
import Modal from './Modal';

export const NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, section: 'Main' },
  { to: '/planner', label: 'Workout Planner', short: 'Plans', icon: ClipboardList, section: 'Main' },
  { to: '/library', label: 'Exercise Library', short: 'Library', icon: Dumbbell, section: 'Main' },
  { to: '/builder', label: 'Workout Builder', short: 'Builder', icon: Hammer, section: 'Main' },
  { to: '/progress', label: 'Progress', icon: BarChart3, section: 'Track' },
  { to: '/calendar', label: 'Calendar', icon: CalendarDays, section: 'Track' },
  { to: '/water', label: 'Water Tracker', short: 'Water', icon: Droplets, section: 'Health' },
  { to: '/bmi', label: 'BMI Calculator', short: 'BMI', icon: Scale, section: 'Health' },
  { to: '/profile', label: 'Profile & Settings', short: 'Profile', icon: UserRound, section: 'Account' },
];

export function Logo({ size = 40 }) {
  return <img src="/icons/icon.svg" alt="FitAtHome logo" className="brand-logo" width={size} height={size} style={{ width: size, height: size }} />;
}

function Sidebar() {
  const { canInstall, install } = useInstallPrompt();
  const online = useOnline();
  const { state } = useApp();
  let lastSection = null;
  return (
    <aside className="sidebar" aria-label="Main navigation">
      <Link to="/" className="brand">
        <Logo />
        <div>
          <div className="brand-name">Fit<span>At</span>Home</div>
          <div className="brand-sub">Smart workout planner</div>
        </div>
      </Link>
      {NAV.map((n) => {
        const header = n.section !== lastSection ? <div className="nav-section">{n.section}</div> : null;
        lastSection = n.section;
        const Icon = n.icon;
        return (
          <div key={n.to}>
            {header}
            <NavLink to={n.to} end={n.to === '/'} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
              <Icon size={19} />
              {n.label}
            </NavLink>
          </div>
        );
      })}
      <div className="sidebar-foot">
        {!online && <span className="offline-pill"><WifiOff size={14} /> Offline mode</span>}
        {canInstall && (
          <button className="btn btn-sm" onClick={install}>
            <Download size={16} /> Install app
          </button>
        )}
        <Link to="/profile" className="card hover" style={{ padding: 12, display: 'flex', gap: 10, alignItems: 'center' }}>
          <div className="avatar" style={{ width: 38, height: 38 }}>{(state.profile.name || 'A').charAt(0).toUpperCase()}</div>
          <div style={{ minWidth: 0 }}>
            <div className="truncate" style={{ fontWeight: 600, fontSize: '0.9rem' }}>{state.profile.name || 'Athlete'}</div>
            <div className="tiny dim">{state.profile.level} · {state.demoMode ? 'Demo mode' : 'Local profile'}</div>
          </div>
        </Link>
      </div>
    </aside>
  );
}

function BottomNav() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  const primary = ['/', '/planner', '/library', '/progress'];
  const moreActive = !primary.some((p) => (p === '/' ? pathname === '/' : pathname.startsWith(p)));
  return (
    <>
      <nav className="bottom-nav" aria-label="Mobile navigation">
        {NAV.filter((n) => primary.includes(n.to)).map((n) => {
          const Icon = n.icon;
          return (
            <NavLink key={n.to} to={n.to} end={n.to === '/'} className={({ isActive }) => (isActive ? 'active' : '')}>
              <Icon size={21} />
              {n.short || n.label}
            </NavLink>
          );
        })}
        <button className={moreActive ? 'active' : ''} onClick={() => setOpen(true)} aria-label="More pages">
          <Grid2x2 size={21} />
          More
        </button>
      </nav>
      {open && (
        <Modal onClose={() => setOpen(false)} title="All features" size="sm">
          <div className="sheet-grid">
            {NAV.map((n) => {
              const Icon = n.icon;
              return (
                <NavLink key={n.to} to={n.to} end={n.to === '/'} onClick={() => setOpen(false)} className={({ isActive }) => (isActive ? 'active' : '')}>
                  <Icon size={22} />
                  {n.short || n.label}
                </NavLink>
              );
            })}
          </div>
        </Modal>
      )}
    </>
  );
}

function DemoBanner() {
  const { state, loadDemo, clearAll, exitDemoKeepData } = useApp();
  const [confirm, setConfirm] = useState(null);
  if (!state.demoMode) return null;
  return (
    <>
      <div className="banner" role="status">
        <Info size={18} />
        <div className="grow">
          <strong>Demo mode</strong> — you're viewing a sample profile with {state.history.length} workouts of realistic history. Everything is fully interactive.
        </div>
        <div className="row wrap">
          <button className="btn btn-sm" onClick={() => setConfirm('reset')}><RotateCcw size={14} /> Reset demo</button>
          <button className="btn btn-sm" onClick={() => setConfirm('fresh')}>Start fresh</button>
          <button className="btn btn-sm btn-ghost btn-icon sm" title="Hide banner (keep data)" onClick={exitDemoKeepData}><X size={16} /></button>
        </div>
      </div>
      {confirm && (
        <Modal title={confirm === 'reset' ? 'Reset demo data?' : 'Start with a clean profile?'} size="sm" onClose={() => setConfirm(null)}>
          <p className="muted">
            {confirm === 'reset'
              ? 'This restores the original sample profile, history and plans. Any changes you made during the demo will be replaced.'
              : 'This removes the sample data and gives you an empty profile to use for real. Saved only in this browser.'}
          </p>
          <div className="row mt-3" style={{ justifyContent: 'flex-end' }}>
            <button className="btn" onClick={() => setConfirm(null)}>Cancel</button>
            <button
              className={confirm === 'reset' ? 'btn btn-primary' : 'btn btn-danger'}
              onClick={() => { confirm === 'reset' ? loadDemo() : clearAll(); setConfirm(null); }}
            >
              {confirm === 'reset' ? 'Reset demo' : 'Clear & start fresh'}
            </button>
          </div>
        </Modal>
      )}
    </>
  );
}

export function Toasts() {
  const { toasts } = useApp();
  return (
    <div className="toasts" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`toast ${t.type}`}>
          {t.type === 'error' ? <AlertTriangle size={18} /> : <CheckCircle2 size={18} />}
          {t.message}
        </div>
      ))}
    </div>
  );
}

export default function Layout() {
  const online = useOnline();
  const { storageOk } = useApp();
  return (
    <div className="app">
      <Sidebar />
      <main className="main">
        <div className="mobile-top">
          <Link to="/" className="row">
            <Logo size={34} />
            <div className="brand-name">Fit<span>At</span>Home</div>
          </Link>
          <div className="row">
            {!online && <span className="offline-pill"><WifiOff size={13} /> Offline</span>}
            <Link to="/profile" className="btn btn-icon sm" aria-label="Profile"><UserRound size={17} /></Link>
          </div>
        </div>
        {!storageOk && (
          <div className="note mb-2"><AlertTriangle size={16} /> Your browser is blocking local storage (private mode?). Changes will be lost when you close the tab.</div>
        )}
        <DemoBanner />
        <Outlet />
      </main>
      <BottomNav />
      <Toasts />
    </div>
  );
}
