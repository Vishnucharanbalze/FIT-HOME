import { Minus, Plus } from 'lucide-react';

export function PageHeader({ eyebrow, title, subtitle, actions }) {
  return (
    <header className="page-head">
      <div>
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <h1>{title}</h1>
        {subtitle && <p>{subtitle}</p>}
      </div>
      {actions && <div className="row wrap">{actions}</div>}
    </header>
  );
}

export function StatCard({ icon: Icon, label, value, unit, trend, color }) {
  return (
    <div className="card stat">
      <div className="stat-icon" style={color ? { color, background: `${color}22` } : undefined}>
        <Icon size={20} />
      </div>
      <div className="stat-value num">
        {value}
        {unit && <small>{unit}</small>}
      </div>
      <div className="stat-label">{label}</div>
      {trend && <div className="stat-trend">{trend}</div>}
    </div>
  );
}

export function ProgressRing({ value = 0, size = 140, stroke = 12, color = 'var(--neon)', track = 'rgba(255,255,255,0.07)', children }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(100, value));
  return (
    <div className="ring-wrap" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={track} strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c - (pct / 100) * c}
          style={{ transition: 'stroke-dashoffset 0.8s cubic-bezier(.22,1,.36,1)', filter: `drop-shadow(0 0 6px ${color === 'var(--neon)' ? 'rgba(198,255,61,.5)' : color})` }}
        />
      </svg>
      <div className="ring-center">{children}</div>
    </div>
  );
}

export function Bar({ value }) {
  return (
    <div className="bar" role="progressbar" aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={100}>
      <span style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
    </div>
  );
}

export function Stepper({ value, onChange, min = 0, max = 999, step = 1, label }) {
  const set = (v) => onChange(Math.max(min, Math.min(max, Number.isNaN(v) ? min : v)));
  return (
    <div className="stepper" aria-label={label}>
      <button type="button" onClick={() => set(value - step)} aria-label={`Decrease ${label || ''}`}><Minus size={14} /></button>
      <input type="number" value={value} min={min} max={max} onChange={(e) => set(parseInt(e.target.value, 10))} aria-label={label} />
      <button type="button" onClick={() => set(value + step)} aria-label={`Increase ${label || ''}`}><Plus size={14} /></button>
    </div>
  );
}

export function Switch({ checked, onChange, label }) {
  return (
    <label className="switch" aria-label={label}>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span />
    </label>
  );
}

export function Empty({ icon: Icon, title, text, action }) {
  return (
    <div className="empty">
      {Icon && <Icon size={40} />}
      <h3 style={{ color: 'var(--text)' }}>{title}</h3>
      {text && <p className="small">{text}</p>}
      {action}
    </div>
  );
}

export function ChartTooltip({ active, payload, label, units = {} }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="chart-tooltip">
      <div className="t">{label}</div>
      {payload.map((p) => (
        <div key={p.dataKey} className="row" style={{ gap: 8 }}>
          <span style={{ width: 8, height: 8, borderRadius: 4, background: p.color || p.fill }} />
          <span style={{ textTransform: 'capitalize' }}>{p.name}:</span>
          <strong className="num">{p.value}{units[p.dataKey] ? ` ${units[p.dataKey]}` : ''}</strong>
        </div>
      ))}
    </div>
  );
}
