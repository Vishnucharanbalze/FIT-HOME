import { useNavigate } from 'react-router-dom';
import { Play, Plus, Repeat, Timer, Layers, Flame, Lightbulb } from 'lucide-react';
import Modal from './Modal';
import ExerciseFigure from './ExerciseFigure';
import { formatTarget } from '../data/exercises';

export default function ExerciseModal({ exercise, onClose }) {
  const navigate = useNavigate();
  if (!exercise) return null;
  const ex = exercise;
  return (
    <Modal title={ex.name} onClose={onClose}>
      <div className="grid grid-2" style={{ alignItems: 'start' }}>
        <div>
          <div className="figure-box"><ExerciseFigure pose={ex.pose} title={ex.name} /></div>
          <div className="ex-meta mt-2">
            <span className={`badge ${ex.difficulty}`}>{ex.difficulty}</span>
            <span className="badge">{ex.category}</span>
          </div>
        </div>
        <div className="col" style={{ gap: 14 }}>
          <div>
            <div className="label">Target muscles</div>
            <div style={{ fontWeight: 600 }}>{ex.muscle}</div>
          </div>
          <div className="grid grid-2" style={{ gap: 10 }}>
            <Info icon={Layers} label="Sets" value={ex.sets} />
            <Info icon={ex.type === 'time' ? Timer : Repeat} label={ex.type === 'time' ? 'Duration' : 'Reps'} value={formatTarget(ex)} />
            <Info icon={Timer} label="Rest" value={`${ex.rest} sec`} />
            <Info icon={Flame} label="Intensity (MET)" value={ex.met} />
          </div>
        </div>
      </div>
      <div className="divider" />
      <h3 className="mb-1">How to do it</h3>
      <ol style={{ margin: 0, paddingLeft: 20, display: 'flex', flexDirection: 'column', gap: 6 }} className="muted">
        {ex.instructions.map((s, i) => <li key={i}>{s}</li>)}
      </ol>
      {ex.tip && (
        <div className="note mt-2"><Lightbulb size={16} /> {ex.tip}</div>
      )}
      <div className="row wrap mt-3" style={{ justifyContent: 'flex-end' }}>
        <button className="btn" onClick={() => navigate(`/builder?add=${ex.id}`)}><Plus size={16} /> Add to custom workout</button>
        <button className="btn btn-primary" onClick={() => navigate(`/workout/ex-${ex.id}`)}><Play size={16} /> Try it now</button>
      </div>
    </Modal>
  );
}

function Info({ icon: Icon, label, value }) {
  return (
    <div className="card" style={{ padding: 12, borderRadius: 14 }}>
      <div className="row tiny dim"><Icon size={14} /> {label}</div>
      <div className="num" style={{ fontWeight: 700, fontSize: '1.15rem', marginTop: 4 }}>{value}</div>
    </div>
  );
}
