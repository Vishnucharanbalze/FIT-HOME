import { memo } from 'react';
import { POSES } from '../data/poses';

/**
 * Animated stick-figure demonstration drawn with SVG + SMIL.
 * Works offline, scales to any size and needs no image files.
 */
const SPLINE = '0.45 0 0.55 1;0.45 0 0.55 1';

const pt = (p) => `${p[0]},${p[1]}`;

function limbs(pose) {
  // front-facing figures spread arms from shoulders and legs from hips
  const sL = pose.front ? [pose.s[0] - 6, pose.s[1] + 2] : pose.s;
  const sR = pose.front ? [pose.s[0] + 6, pose.s[1] + 2] : pose.s;
  const pL = pose.front ? [pose.p[0] - 4, pose.p[1]] : pose.p;
  const pR = pose.front ? [pose.p[0] + 4, pose.p[1]] : pose.p;
  const c = pose.c || [(pose.s[0] + pose.p[0]) / 2, (pose.s[1] + pose.p[1]) / 2];
  return {
    farArm: `${pt(sR)} ${pt(pose.re)} ${pt(pose.rh)}`,
    farLeg: `${pt(pR)} ${pt(pose.rk)} ${pt(pose.rf)}`,
    nearArm: `${pt(sL)} ${pt(pose.le)} ${pt(pose.lh)}`,
    nearLeg: `${pt(pL)} ${pt(pose.lk)} ${pt(pose.lf)}`,
    torso: `M${pt(pose.s)} Q${pt(c)} ${pt(pose.p)}`,
    shoulders: pose.front ? `${pt(sL)} ${pt(sR)}` : `${pt(pose.s)} ${pt(pose.s)}`,
    hips: pose.front ? `${pt(pL)} ${pt(pR)}` : `${pt(pose.p)} ${pt(pose.p)}`,
    hx: pose.h[0],
    hy: pose.h[1],
  };
}

function Anim({ attr, a, b, dur }) {
  if (a === b) return null;
  return (
    <animate
      attributeName={attr}
      values={`${a};${b};${a}`}
      keyTimes="0;0.5;1"
      calcMode="spline"
      keySplines={SPLINE}
      dur={dur}
      repeatCount="indefinite"
    />
  );
}

function Prop({ type }) {
  const st = { stroke: 'rgba(255,255,255,0.22)', strokeWidth: 1.5, fill: 'rgba(255,255,255,0.04)' };
  if (type === 'wall') return <rect x={34} y={8} width={4} height={84} rx={1} {...st} />;
  if (type === 'chair') return <g {...st}><rect x={26} y={68} width={24} height={4} rx={1} /><line x1={28} y1={72} x2={28} y2={92} /><line x1={48} y1={72} x2={48} y2={92} /></g>;
  if (type === 'box') return <rect x={64} y={76} width={34} height={16} rx={2} {...st} />;
  return null;
}

function ExerciseFigure({ pose = 'stand', animate = true, speed = 1.6, color = '#c6ff3d', title }) {
  const frames = POSES[pose] || POSES.stand;
  const A = limbs(frames[0]);
  const B = limbs(frames[1]);
  const dur = `${speed}s`;
  const prop = frames[0].prop;
  const line = { fill: 'none', strokeLinecap: 'round', strokeLinejoin: 'round' };
  const on = animate;

  return (
    <svg viewBox="0 0 120 100" role="img" aria-label={title ? `${title} demonstration` : 'Exercise demonstration'}>
      <defs>
        <filter id="fig-glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="1.4" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <line x1={6} y1={92.5} x2={114} y2={92.5} stroke="rgba(255,255,255,0.14)" strokeWidth={1} strokeDasharray="2 3" />
      {prop && <Prop type={prop} />}
      <g filter="url(#fig-glow)">
        {/* far limbs (dimmer) */}
        <polyline points={A.farArm} stroke={color} strokeOpacity={0.45} strokeWidth={3.6} {...line}>
          {on && <Anim attr="points" a={A.farArm} b={B.farArm} dur={dur} />}
        </polyline>
        <polyline points={A.farLeg} stroke={color} strokeOpacity={0.45} strokeWidth={4.2} {...line}>
          {on && <Anim attr="points" a={A.farLeg} b={B.farLeg} dur={dur} />}
        </polyline>
        {/* torso */}
        <path d={A.torso} stroke={color} strokeWidth={5} {...line}>
          {on && <Anim attr="d" a={A.torso} b={B.torso} dur={dur} />}
        </path>
        <polyline points={A.shoulders} stroke={color} strokeWidth={4.5} {...line}>
          {on && <Anim attr="points" a={A.shoulders} b={B.shoulders} dur={dur} />}
        </polyline>
        <polyline points={A.hips} stroke={color} strokeWidth={4.5} {...line}>
          {on && <Anim attr="points" a={A.hips} b={B.hips} dur={dur} />}
        </polyline>
        {/* near limbs */}
        <polyline points={A.nearLeg} stroke={color} strokeWidth={4.4} {...line}>
          {on && <Anim attr="points" a={A.nearLeg} b={B.nearLeg} dur={dur} />}
        </polyline>
        <polyline points={A.nearArm} stroke={color} strokeWidth={3.8} {...line}>
          {on && <Anim attr="points" a={A.nearArm} b={B.nearArm} dur={dur} />}
        </polyline>
        {/* head */}
        <circle cx={A.hx} cy={A.hy} r={5.6} fill={color}>
          {on && <Anim attr="cx" a={A.hx} b={B.hx} dur={dur} />}
          {on && <Anim attr="cy" a={A.hy} b={B.hy} dur={dur} />}
        </circle>
      </g>
    </svg>
  );
}

export default memo(ExerciseFigure);
