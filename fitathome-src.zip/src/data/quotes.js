export const QUOTES = [
  { text: 'The only bad workout is the one that didn’t happen.', tag: 'Consistency' },
  { text: 'Small daily improvements are the key to staggering long-term results.', tag: 'Progress' },
  { text: 'Your living room is your gym. No excuses, just effort.', tag: 'Home training' },
  { text: 'Discipline is choosing between what you want now and what you want most.', tag: 'Mindset' },
  { text: 'Sweat is just fat crying. Keep going!', tag: 'Motivation' },
  { text: 'You don’t have to be extreme, just consistent.', tag: 'Consistency' },
  { text: 'Strong is built one rep at a time.', tag: 'Strength' },
  { text: 'Take care of your body. It’s the only place you have to live.', tag: 'Health' },
  { text: 'Motivation gets you started. Habit keeps you going.', tag: 'Habit' },
  { text: 'Fall in love with taking care of yourself.', tag: 'Self-care' },
  { text: 'A 20-minute workout is better than a zero-minute workout.', tag: 'Progress' },
  { text: 'Rest days are part of the plan — recovery builds the muscle.', tag: 'Recovery' },
  { text: 'Believe you can and you’re halfway there.', tag: 'Mindset' },
  { text: 'Don’t count the days. Make the days count.', tag: 'Motivation' },
];

export const quoteOfTheDay = (offset = 0) => {
  const d = new Date();
  const dayIndex = Math.floor(new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() / 86400000);
  return QUOTES[(dayIndex + offset) % QUOTES.length];
};
