import { EXERCISE_MAP } from './exercises';

export const LEVELS = ['Beginner', 'Intermediate', 'Advanced'];
export const GOALS = ['Weight Loss', 'Muscle Building', 'Full Body', 'Abs', 'Beginner', 'Strength', 'Flexibility', 'General Fitness'];
export const WEEKDAY_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/** Build one plan item using the exercise's own type (reps or time). */
const item = (exerciseId, sets, amount, rest) => {
  const ex = EXERCISE_MAP[exerciseId];
  if (!ex) throw new Error(`Unknown exercise ${exerciseId}`);
  return ex.type === 'time'
    ? { exerciseId, sets, duration: amount, rest }
    : { exerciseId, sets, reps: amount, rest };
};

/**
 * Predefined plans. Values are the "Intermediate" baseline; the planner scales
 * them for Beginner / Advanced (see utils/workout.js -> scaleItems).
 * days: 0 = Sunday ... 6 = Saturday
 */
export const BUILT_IN_PLANS = [
  {
    id: 'weight-loss',
    name: 'Fat Burn HIIT',
    goal: 'Weight Loss',
    level: 'Intermediate',
    color: '#c6ff3d',
    description: 'High-intensity intervals that keep your heart rate up to maximise calorie burn.',
    days: [1, 3, 5],
    items: [
      item('jumping-jacks', 2, 40, 20),
      item('high-knees', 3, 30, 20),
      item('squats', 3, 15, 30),
      item('mountain-climbers', 3, 30, 30),
      item('burpees', 3, 8, 45),
      item('skaters', 3, 30, 30),
      item('butt-kicks', 2, 30, 20),
      item('plank', 2, 30, 30),
    ],
  },
  {
    id: 'muscle-building',
    name: 'Muscle Builder',
    goal: 'Muscle Building',
    level: 'Intermediate',
    color: '#3dff8b',
    description: 'Higher-volume bodyweight training with controlled tempo to build lean muscle.',
    days: [1, 2, 4, 5],
    items: [
      item('push-ups', 4, 12, 60),
      item('wide-push-ups', 3, 12, 60),
      item('tricep-dips', 3, 12, 45),
      item('pike-push-ups', 3, 10, 60),
      item('bulgarian-split-squats', 3, 10, 60),
      item('lunges', 3, 12, 45),
      item('glute-bridges', 3, 15, 30),
      item('superman', 3, 12, 30),
    ],
  },
  {
    id: 'full-body',
    name: 'Total Body Blast',
    goal: 'Full Body',
    level: 'Intermediate',
    color: '#5ee7ff',
    description: 'Hit every major muscle group in one balanced session.',
    days: [2, 4, 6],
    items: [
      item('inchworms', 2, 6, 30),
      item('squats', 3, 15, 40),
      item('push-ups', 3, 12, 45),
      item('reverse-lunges', 3, 12, 40),
      item('plank-up-downs', 3, 10, 45),
      item('glute-bridges', 3, 15, 30),
      item('bear-crawl', 2, 30, 40),
      item('plank', 2, 40, 30),
    ],
  },
  {
    id: 'abs-workout',
    name: 'Core Crusher Abs',
    goal: 'Abs',
    level: 'Intermediate',
    color: '#ffd23d',
    description: 'A focused core circuit for abs, obliques and lower-back stability.',
    days: [2, 4],
    items: [
      item('crunches', 3, 20, 30),
      item('bicycle-crunches', 3, 20, 30),
      item('leg-raises', 3, 12, 30),
      item('russian-twists', 3, 20, 30),
      item('flutter-kicks', 3, 30, 30),
      item('dead-bug', 2, 12, 30),
      item('heel-touches', 2, 20, 30),
      item('plank', 3, 40, 30),
    ],
  },
  {
    id: 'beginner',
    name: 'Beginner Starter',
    goal: 'Beginner',
    level: 'Beginner',
    color: '#b08cff',
    description: 'Gentle, joint-friendly moves to build a habit and learn proper form.',
    days: [1, 3, 5],
    items: [
      item('arm-circles', 1, 30, 15),
      item('jumping-jacks', 2, 30, 30),
      item('squats', 3, 12, 45),
      item('knee-push-ups', 3, 8, 45),
      item('glute-bridges', 3, 12, 30),
      item('bird-dog', 2, 10, 30),
      item('plank', 2, 20, 30),
      item('childs-pose', 1, 40, 10),
    ],
  },
  {
    id: 'strength',
    name: 'Bodyweight Strength',
    goal: 'Strength',
    level: 'Advanced',
    color: '#ff7a3d',
    description: 'Slow, hard progressions that build real strength with zero equipment.',
    days: [1, 3, 5],
    items: [
      item('push-ups', 4, 15, 75),
      item('diamond-push-ups', 3, 10, 75),
      item('pistol-squats', 3, 6, 90),
      item('bulgarian-split-squats', 3, 10, 75),
      item('pike-push-ups', 3, 10, 75),
      item('single-leg-bridges', 3, 10, 45),
      item('hollow-hold', 3, 30, 45),
      item('side-plank', 2, 30, 30),
    ],
  },
  {
    id: 'flexibility',
    name: 'Flexibility Flow',
    goal: 'Flexibility',
    level: 'Beginner',
    color: '#ff5ea8',
    description: 'A calming mobility routine to improve range of motion and speed up recovery.',
    days: [0, 6],
    items: [
      item('cat-cow', 1, 40, 10),
      item('downward-dog', 2, 30, 10),
      item('cobra-stretch', 2, 30, 10),
      item('hip-flexor-stretch', 2, 30, 10),
      item('seated-hamstring', 2, 30, 10),
      item('butterfly-stretch', 1, 40, 10),
      item('quad-stretch', 2, 30, 10),
      item('shoulder-stretch', 2, 30, 10),
      item('childs-pose', 1, 45, 0),
    ],
  },
];

export const BUILT_IN_MAP = Object.fromEntries(BUILT_IN_PLANS.map((p) => [p.id, p]));
