import { BUILT_IN_MAP } from './plans';
import { EXERCISE_MAP } from './exercises';
import { scaleItems, estimateDuration, estimateCalories } from '../utils/workout';
import { toKey, addDays, startOfDay } from '../utils/date';

export const STORAGE_KEY = 'fitathome:v1';
export const SCHEMA_VERSION = 1;

/** Deterministic pseudo-random generator so the demo always looks the same. */
function mulberry32(seed) {
  return function rand() {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const DEFAULT_PREFERENCES = {
  sound: true,
  voice: true,
  vibrate: true,
  countdown: 5,
  autoAdvance: true,
};

export const DEFAULT_PROFILE = {
  name: 'Athlete',
  age: '',
  gender: '',
  heightCm: 170,
  weightKg: 70,
  goal: 'General Fitness',
  level: 'Beginner',
  duration: 30,
};

/** Empty app state used by "Start fresh". */
export function createEmptyState() {
  return {
    version: SCHEMA_VERSION,
    demoMode: false,
    profile: { ...DEFAULT_PROFILE },
    preferences: { ...DEFAULT_PREFERENCES },
    customPlans: [],
    scheduledPlanIds: ['beginner'],
    planDays: {},
    history: [],
    water: { goalMl: 2500, logs: {} },
    measurements: [],
    createdAt: new Date().toISOString(),
  };
}

function makeEntry({ date, plan, level, weightKg, rand, completed }) {
  const items = plan.builtIn === false ? plan.items : scaleItems(plan.items, level, plan.level);
  const totalExercises = items.length;
  const doneCount = completed ? totalExercises : Math.max(2, Math.floor(totalExercises * (0.45 + rand() * 0.35)));
  const doneItems = items.slice(0, doneCount);
  const est = estimateDuration(doneItems);
  const durationSec = Math.round(est * (0.92 + rand() * 0.18));
  const calories = Math.round(estimateCalories(doneItems, weightKg) * (0.95 + rand() * 0.12));
  return {
    id: `h-${toKey(date)}-${plan.id}-${Math.floor(rand() * 1e6)}`,
    date: date.toISOString(),
    dayKey: toKey(date),
    planId: plan.id,
    planName: plan.name,
    level,
    durationSec,
    calories,
    totalExercises,
    exercisesCompleted: doneCount,
    completed,
    exercises: items.map((it, i) => ({
      exerciseId: it.exerciseId,
      name: EXERCISE_MAP[it.exerciseId]?.name,
      totalSets: it.sets,
      setsDone: i < doneCount ? it.sets : 0,
      reps: it.reps ?? null,
      duration: it.duration ?? null,
    })),
  };
}

/**
 * Builds a realistic demo account with ~10 weeks of history generated relative
 * to TODAY, so the dashboard, charts, streak and calendar always look alive.
 */
export function createDemoState() {
  const rand = mulberry32(20261110);
  const today = startOfDay(new Date());

  const customPlan = {
    id: 'custom-weekend-warrior',
    name: 'Weekend Warrior',
    goal: 'General Fitness',
    level: 'Intermediate',
    color: '#5ee7ff',
    description: 'My own Saturday circuit — a mix of cardio, legs and core.',
    days: [6],
    builtIn: false,
    createdAt: addDays(today, -40).toISOString(),
    items: [
      { exerciseId: 'jumping-jacks', sets: 2, duration: 40, rest: 20 },
      { exerciseId: 'squats', sets: 3, reps: 15, rest: 40 },
      { exerciseId: 'push-ups', sets: 3, reps: 12, rest: 45 },
      { exerciseId: 'reverse-lunges', sets: 3, reps: 12, rest: 40 },
      { exerciseId: 'mountain-climbers', sets: 3, duration: 30, rest: 30 },
      { exerciseId: 'russian-twists', sets: 3, reps: 20, rest: 30 },
      { exerciseId: 'plank', sets: 2, duration: 45, rest: 30 },
    ],
  };
  const customCore = {
    id: 'custom-quick-core',
    name: 'Quick 10-min Core',
    goal: 'Abs',
    level: 'Beginner',
    color: '#ffd23d',
    description: 'A short core finisher for busy days.',
    days: [],
    builtIn: false,
    createdAt: addDays(today, -25).toISOString(),
    items: [
      { exerciseId: 'crunches', sets: 2, reps: 20, rest: 20 },
      { exerciseId: 'leg-raises', sets: 2, reps: 12, rest: 20 },
      { exerciseId: 'bicycle-crunches', sets: 2, reps: 20, rest: 20 },
      { exerciseId: 'plank', sets: 2, duration: 30, rest: 20 },
    ],
  };

  const schedule = {
    1: BUILT_IN_MAP['weight-loss'],
    3: BUILT_IN_MAP['weight-loss'],
    5: BUILT_IN_MAP['weight-loss'],
    2: BUILT_IN_MAP['abs-workout'],
    4: BUILT_IN_MAP['abs-workout'],
    6: customPlan,
  };

  const history = [];
  const DAYS = 72;
  let weight = 76.2;
  for (let i = DAYS; i >= 1; i--) {
    const date = addDays(today, -i);
    const wd = date.getDay();
    const plan = schedule[wd];
    // Adherence improves over time: ~70% early on, ~95% in recent weeks
    const adherence = 0.68 + (1 - i / DAYS) * 0.3;
    const recent = i <= 9; // keep a clean recent streak for the demo
    if (plan && (recent || rand() < adherence)) {
      const level = i > 45 ? 'Beginner' : 'Intermediate';
      const completed = recent ? true : rand() < 0.86;
      const hour = 6 + Math.floor(rand() * 3) + (rand() < 0.35 ? 11 : 0);
      date.setHours(hour, Math.floor(rand() * 60));
      history.push(makeEntry({ date: new Date(date), plan: { ...plan, builtIn: plan.builtIn !== false && !plan.id.startsWith('custom') }, level, weightKg: weight, rand, completed }));
    } else if (!plan && rand() < 0.18) {
      date.setHours(18, Math.floor(rand() * 60));
      history.push(makeEntry({ date: new Date(date), plan: { ...BUILT_IN_MAP.flexibility, builtIn: true }, level: 'Beginner', weightKg: weight, rand, completed: true }));
    }
    // occasional quick core add-on
    if (plan && rand() < 0.08) {
      const d2 = addDays(today, -i);
      d2.setHours(20, 15);
      history.push(makeEntry({ date: d2, plan: customCore, level: 'Beginner', weightKg: weight, rand, completed: true }));
    }
    weight -= 0.055;
  }

  // Weekly body measurements trending down
  const measurements = [];
  for (let w = 10; w >= 0; w--) {
    const d = addDays(today, -w * 7);
    const kg = Math.round((76.4 - (10 - w) * 0.42 + (rand() - 0.5) * 0.4) * 10) / 10;
    measurements.push({ id: `m-${w}`, date: d.toISOString(), dayKey: toKey(d), heightCm: 175, weightKg: kg });
  }
  const currentWeight = measurements[measurements.length - 1].weightKg;

  // Water logs for the past 2 weeks + some for today
  const logs = {};
  for (let i = 14; i >= 1; i--) {
    const d = addDays(today, -i);
    const n = 5 + Math.floor(rand() * 6);
    logs[toKey(d)] = Array.from({ length: n }, (_, j) => ({
      id: `w-${i}-${j}`,
      ml: [250, 250, 300, 500, 200][Math.floor(rand() * 5)],
      time: new Date(d.getFullYear(), d.getMonth(), d.getDate(), 7 + j * 1.6).toISOString(),
    }));
  }
  const now = new Date();
  const todayLogs = [];
  [250, 500, 250].forEach((ml, j) => {
    const t = new Date(today);
    t.setHours(Math.min(now.getHours(), 8 + j * 2), 10);
    todayLogs.push({ id: `w-today-${j}`, ml, time: t.toISOString() });
  });
  logs[toKey(today)] = todayLogs;

  return {
    version: SCHEMA_VERSION,
    demoMode: true,
    profile: {
      name: 'Arjun Sharma',
      age: 22,
      gender: 'Male',
      heightCm: 175,
      weightKg: currentWeight,
      goal: 'Weight Loss',
      level: 'Intermediate',
      duration: 30,
    },
    preferences: { ...DEFAULT_PREFERENCES },
    customPlans: [customPlan, customCore],
    scheduledPlanIds: ['weight-loss', 'abs-workout', 'custom-weekend-warrior'],
    planDays: { 'abs-workout': [2, 4] },
    history: history.sort((a, b) => (a.date < b.date ? -1 : 1)),
    water: { goalMl: 3000, logs },
    measurements,
    createdAt: addDays(today, -DAYS).toISOString(),
  };
}
