/**
 * Built-in exercise library (stored locally — no API).
 * type: 'reps' (sets x reps) or 'time' (sets x duration seconds)
 * met: Metabolic Equivalent used for the calorie estimate (MET x kg x hours)
 * pose: key into POSES for the animated illustration
 */

export const CATEGORIES = ['Upper Body', 'Lower Body', 'Core', 'Cardio', 'Full Body', 'Flexibility'];
export const DIFFICULTIES = ['Beginner', 'Intermediate', 'Advanced'];

const r = (sets, reps, rest, met) => ({ type: 'reps', sets, reps, rest, met });
const t = (sets, duration, rest, met) => ({ type: 'time', sets, duration, rest, met });

const E = (id, name, category, muscle, difficulty, pose, cfg, instructions, tip = '') => ({
  id, name, category, muscle, difficulty, pose, ...cfg, instructions, tip,
});

export const EXERCISES = [
  // ---------- UPPER BODY ----------
  E('push-ups', 'Push-ups', 'Upper Body', 'Chest, Triceps, Shoulders', 'Beginner', 'pushup', r(3, 12, 45, 8), [
    'Start in a high plank with hands slightly wider than shoulders.',
    'Keep your body in a straight line from head to heels.',
    'Lower your chest until it is just above the floor.',
    'Push back up to the start, fully extending your arms.',
  ], 'Squeeze your glutes to stop your hips from sagging.'),
  E('knee-push-ups', 'Knee Push-ups', 'Upper Body', 'Chest, Triceps', 'Beginner', 'kneepushup', r(3, 10, 40, 6), [
    'Kneel on a mat and place your hands under your shoulders.',
    'Walk your hands forward so your body forms a line from knees to head.',
    'Bend your elbows to lower your chest toward the floor.',
    'Press back up while keeping your core tight.',
  ], 'A great stepping stone to full push-ups.'),
  E('wide-push-ups', 'Wide Push-ups', 'Upper Body', 'Chest, Front Shoulders', 'Intermediate', 'pushup', r(3, 12, 45, 8), [
    'Set your hands about 1.5x shoulder width apart.',
    'Brace your core and keep your neck neutral.',
    'Lower slowly until your chest nearly touches the floor.',
    'Drive through your palms to return to the top.',
  ]),
  E('diamond-push-ups', 'Diamond Push-ups', 'Upper Body', 'Triceps, Inner Chest', 'Advanced', 'pushup', r(3, 10, 60, 8), [
    'Place your hands together under your chest, forming a diamond with thumbs and index fingers.',
    'Extend your legs into a plank position.',
    'Lower your chest to your hands, keeping elbows close to your body.',
    'Press back up powerfully.',
  ], 'Drop to your knees if your form breaks down.'),
  E('incline-push-ups', 'Incline Push-ups', 'Upper Body', 'Lower Chest, Triceps', 'Beginner', 'pushup', r(3, 12, 40, 6), [
    'Place your hands on a sturdy chair, bench or couch edge.',
    'Step your feet back into a straight-body plank.',
    'Lower your chest to the edge of the surface.',
    'Push back up while keeping your body rigid.',
  ]),
  E('decline-push-ups', 'Decline Push-ups', 'Upper Body', 'Upper Chest, Shoulders', 'Advanced', 'pushup', r(3, 10, 60, 8), [
    'Place your feet on a sturdy chair or step behind you.',
    'Put your hands on the floor under your shoulders.',
    'Lower your head and chest toward the floor with control.',
    'Press back to the start without letting your hips drop.',
  ]),
  E('pike-push-ups', 'Pike Push-ups', 'Upper Body', 'Shoulders, Triceps', 'Intermediate', 'pike', r(3, 10, 60, 7), [
    'Start in a downward-dog position with hips high.',
    'Bend your elbows to lower the top of your head toward the floor.',
    'Keep your hips stacked over your shoulders.',
    'Press back up to the inverted V.',
  ], 'A body-weight alternative to an overhead press.'),
  E('tricep-dips', 'Tricep Dips', 'Upper Body', 'Triceps, Shoulders', 'Beginner', 'dip', r(3, 12, 45, 5), [
    'Sit on the edge of a sturdy chair, hands gripping the edge beside your hips.',
    'Slide your hips off the chair with your legs bent or extended.',
    'Bend your elbows to about 90° to lower your body.',
    'Push through your palms to straighten your arms.',
  ], 'Keep your back close to the chair to protect your shoulders.'),
  E('shoulder-taps', 'Plank Shoulder Taps', 'Upper Body', 'Shoulders, Core', 'Intermediate', 'shouldertap', r(3, 20, 45, 6), [
    'Start in a high plank with feet wider than hip width.',
    'Lift one hand and tap the opposite shoulder.',
    'Place it back down and repeat on the other side.',
    'Keep your hips as still as possible.',
  ]),
  E('arm-circles', 'Arm Circles', 'Upper Body', 'Shoulders', 'Beginner', 'armcircle', t(2, 30, 15, 3), [
    'Stand tall with arms extended out to the sides at shoulder height.',
    'Make small controlled circles forward.',
    'Gradually increase the size of the circles.',
    'Reverse direction halfway through.',
  ], 'Perfect warm-up before any upper-body session.'),
  E('plank-up-downs', 'Plank Up-Downs', 'Upper Body', 'Triceps, Shoulders, Core', 'Intermediate', 'planktap', r(3, 10, 45, 8), [
    'Start in a forearm plank.',
    'Place one hand, then the other, to press up into a high plank.',
    'Lower back down to your forearms one arm at a time.',
    'Alternate the leading arm each rep.',
  ]),
  E('archer-push-ups', 'Archer Push-ups', 'Upper Body', 'Chest, Triceps, Lats', 'Advanced', 'pushup', r(3, 8, 75, 8), [
    'Take a very wide push-up stance.',
    'Shift your weight toward one hand as you lower down.',
    'Keep the other arm almost straight like drawing a bow.',
    'Push back to center and alternate sides.',
  ]),
  E('superman', 'Superman', 'Upper Body', 'Lower Back, Glutes', 'Beginner', 'superman', r(3, 12, 30, 3.5), [
    'Lie face down with arms extended overhead.',
    'Lift your arms, chest and legs off the floor together.',
    'Hold for one to two seconds at the top.',
    'Lower slowly with control.',
  ], 'Look at the floor to keep your neck neutral.'),
  E('reverse-snow-angels', 'Reverse Snow Angels', 'Upper Body', 'Upper Back, Rear Shoulders', 'Beginner', 'snowangel', r(3, 12, 30, 3.5), [
    'Lie face down with arms by your sides, palms down.',
    'Lift your chest and arms slightly off the floor.',
    'Sweep your arms in an arc until they are overhead.',
    'Sweep them back to your sides and repeat.',
  ]),

  // ---------- LOWER BODY ----------
  E('squats', 'Squats', 'Lower Body', 'Quads, Glutes, Hamstrings', 'Beginner', 'squat', r(3, 15, 45, 5), [
    'Stand with feet shoulder-width apart, toes slightly out.',
    'Push your hips back and bend your knees as if sitting in a chair.',
    'Lower until your thighs are about parallel to the floor.',
    'Drive through your heels to stand back up.',
  ], 'Keep your chest up and knees tracking over your toes.'),
  E('jump-squats', 'Jump Squats', 'Lower Body', 'Quads, Glutes, Calves', 'Intermediate', 'jumpsquat', r(3, 12, 60, 8), [
    'Lower into a regular squat.',
    'Explode upward, jumping as high as you can.',
    'Land softly with bent knees.',
    'Go straight into the next squat.',
  ], 'Land quietly — soft landings protect your knees.'),
  E('sumo-squats', 'Sumo Squats', 'Lower Body', 'Inner Thighs, Glutes', 'Beginner', 'squat', r(3, 15, 45, 5), [
    'Stand with feet wide and toes turned out about 45°.',
    'Keep your torso upright and lower your hips straight down.',
    'Push your knees out in line with your toes.',
    'Squeeze your glutes as you rise.',
  ]),
  E('lunges', 'Forward Lunges', 'Lower Body', 'Quads, Glutes', 'Beginner', 'lunge', r(3, 12, 45, 4), [
    'Stand tall with feet hip-width apart.',
    'Step forward and lower until both knees are at about 90°.',
    'Keep your front knee over your ankle.',
    'Push off the front foot to return. Alternate legs.',
  ]),
  E('reverse-lunges', 'Reverse Lunges', 'Lower Body', 'Glutes, Hamstrings', 'Beginner', 'lunge', r(3, 12, 45, 4), [
    'Stand tall with hands on hips.',
    'Step one foot back and lower your back knee toward the floor.',
    'Keep most of your weight in the front heel.',
    'Return to standing and switch legs.',
  ], 'Easier on the knees than forward lunges.'),
  E('side-lunges', 'Side Lunges', 'Lower Body', 'Adductors, Glutes', 'Intermediate', 'sidelunge', r(3, 10, 45, 4.5), [
    'Stand with feet together.',
    'Take a big step to the side and bend that knee.',
    'Keep the other leg straight and push your hips back.',
    'Push off to return and alternate sides.',
  ]),
  E('curtsy-lunges', 'Curtsy Lunges', 'Lower Body', 'Glutes, Outer Thighs', 'Intermediate', 'curtsy', r(3, 10, 45, 4.5), [
    'Stand with feet hip-width apart.',
    'Step one leg diagonally behind the other.',
    'Lower your back knee toward the floor.',
    'Return to start and alternate sides.',
  ]),
  E('bulgarian-split-squats', 'Bulgarian Split Squats', 'Lower Body', 'Quads, Glutes', 'Advanced', 'lunge', r(3, 10, 60, 6), [
    'Stand two steps in front of a chair, facing away.',
    'Place the top of one foot on the chair behind you.',
    'Lower straight down until your front thigh is parallel to the floor.',
    'Drive up through the front heel. Complete all reps, then switch.',
  ]),
  E('glute-bridges', 'Glute Bridges', 'Lower Body', 'Glutes, Hamstrings', 'Beginner', 'bridge', r(3, 15, 30, 3.5), [
    'Lie on your back with knees bent and feet flat on the floor.',
    'Press through your heels and lift your hips.',
    'Squeeze your glutes hard at the top.',
    'Lower slowly back to the floor.',
  ]),
  E('single-leg-bridges', 'Single-Leg Glute Bridges', 'Lower Body', 'Glutes, Hamstrings, Core', 'Intermediate', 'singlebridge', r(3, 10, 45, 4), [
    'Lie on your back with one knee bent and the other leg extended.',
    'Drive through the planted heel to lift your hips.',
    'Keep your hips level at the top.',
    'Lower with control. Complete all reps, then switch.',
  ]),
  E('wall-sit', 'Wall Sit', 'Lower Body', 'Quads, Glutes', 'Beginner', 'wallsit', t(3, 40, 45, 4), [
    'Stand with your back against a wall.',
    'Slide down until your knees are bent at 90°.',
    'Keep your back flat against the wall.',
    'Hold the position while breathing steadily.',
  ], 'Push your heels into the floor to stay engaged.'),
  E('calf-raises', 'Calf Raises', 'Lower Body', 'Calves', 'Beginner', 'calf', r(3, 20, 30, 3), [
    'Stand tall, holding a wall or chair for balance if needed.',
    'Rise onto the balls of your feet as high as you can.',
    'Pause briefly at the top.',
    'Lower your heels slowly back down.',
  ]),
  E('donkey-kicks', 'Donkey Kicks', 'Lower Body', 'Glutes', 'Beginner', 'donkeykick', r(3, 15, 30, 4), [
    'Start on all fours with hands under shoulders and knees under hips.',
    'Keeping the knee bent, lift one leg until the thigh is parallel to the floor.',
    'Squeeze the glute at the top.',
    'Lower and repeat. Switch sides after the set.',
  ]),
  E('fire-hydrants', 'Fire Hydrants', 'Lower Body', 'Glute Medius, Hips', 'Beginner', 'firehydrant', r(3, 15, 30, 4), [
    'Start on all fours.',
    'Keeping your knee bent, lift one leg out to the side.',
    'Keep your torso still and core tight.',
    'Lower slowly. Switch sides after the set.',
  ]),
  E('step-ups', 'Step-ups', 'Lower Body', 'Quads, Glutes', 'Beginner', 'stepup', r(3, 12, 45, 6), [
    'Stand facing a sturdy step or low stool.',
    'Step up with one foot and press through that heel.',
    'Bring the other foot up to stand tall.',
    'Step down with control and alternate the lead leg.',
  ]),
  E('pistol-squats', 'Assisted Pistol Squats', 'Lower Body', 'Quads, Glutes, Balance', 'Advanced', 'pistol', r(3, 6, 75, 6), [
    'Stand on one leg, holding a door frame or chair for support.',
    'Extend the other leg in front of you.',
    'Lower slowly on the standing leg as far as you can control.',
    'Push back up. Complete all reps, then switch legs.',
  ]),
  E('good-mornings', 'Good Mornings', 'Lower Body', 'Hamstrings, Lower Back', 'Beginner', 'hinge', r(3, 12, 30, 3.5), [
    'Stand with feet hip-width apart, hands behind your head.',
    'Hinge at the hips, pushing them back with a slight knee bend.',
    'Lower your torso until you feel a hamstring stretch.',
    'Squeeze your glutes to return upright.',
  ]),

  // ---------- CORE ----------
  E('plank', 'Plank', 'Core', 'Core, Shoulders', 'Beginner', 'plank', t(3, 30, 30, 4), [
    'Rest on your forearms with elbows under your shoulders.',
    'Extend your legs and lift your body into a straight line.',
    'Brace your abs and squeeze your glutes.',
    'Hold while breathing normally.',
  ], 'Do not let your hips sag or pike up.'),
  E('side-plank', 'Side Plank', 'Core', 'Obliques', 'Intermediate', 'sideplank', t(3, 25, 30, 4), [
    'Lie on your side with your elbow under your shoulder.',
    'Stack your feet and lift your hips off the floor.',
    'Form a straight line from head to feet.',
    'Hold, then switch sides on the next set.',
  ]),
  E('crunches', 'Crunches', 'Core', 'Upper Abs', 'Beginner', 'crunch', r(3, 20, 30, 3.8), [
    'Lie on your back with knees bent and feet flat.',
    'Place your fingertips lightly behind your ears.',
    'Curl your shoulders off the floor using your abs.',
    'Lower slowly without pulling on your neck.',
  ]),
  E('bicycle-crunches', 'Bicycle Crunches', 'Core', 'Obliques, Abs', 'Intermediate', 'bicycle', r(3, 20, 30, 5), [
    'Lie on your back with hands behind your head and legs lifted.',
    'Bring one knee toward your chest while extending the other leg.',
    'Rotate to bring the opposite elbow toward the bent knee.',
    'Switch sides in a pedalling motion.',
  ]),
  E('leg-raises', 'Leg Raises', 'Core', 'Lower Abs, Hip Flexors', 'Intermediate', 'legraise', r(3, 12, 40, 4), [
    'Lie flat with legs straight and hands by your sides.',
    'Keep your lower back pressed into the floor.',
    'Lift your legs until they point at the ceiling.',
    'Lower slowly, stopping just above the floor.',
  ]),
  E('flutter-kicks', 'Flutter Kicks', 'Core', 'Lower Abs', 'Intermediate', 'flutter', t(3, 30, 30, 4.5), [
    'Lie on your back with legs extended.',
    'Lift your heels a few inches off the floor.',
    'Alternate small, quick up-and-down kicks.',
    'Keep your lower back on the floor throughout.',
  ]),
  E('russian-twists', 'Russian Twists', 'Core', 'Obliques', 'Intermediate', 'twist', r(3, 20, 30, 5), [
    'Sit with knees bent and lean back slightly.',
    'Lift your feet off the floor for an extra challenge.',
    'Rotate your torso to touch the floor beside each hip.',
    'Move with control, counting each side as one rep.',
  ]),
  E('mountain-climbers', 'Mountain Climbers', 'Core', 'Core, Hip Flexors, Shoulders', 'Intermediate', 'mountain', t(3, 30, 30, 8), [
    'Start in a high plank position.',
    'Drive one knee toward your chest.',
    'Quickly switch legs, like running in place.',
    'Keep your hips low and shoulders over your wrists.',
  ]),
  E('dead-bug', 'Dead Bug', 'Core', 'Deep Core, Abs', 'Beginner', 'deadbug', r(3, 12, 30, 3.5), [
    'Lie on your back with arms toward the ceiling and knees bent at 90°.',
    'Slowly extend the opposite arm and leg toward the floor.',
    'Keep your lower back pressed down.',
    'Return and switch sides.',
  ], 'Move slowly — control matters more than speed.'),
  E('bird-dog', 'Bird Dog', 'Core', 'Core, Lower Back, Glutes', 'Beginner', 'birddog', r(3, 12, 30, 3), [
    'Start on all fours with a flat back.',
    'Extend one arm forward and the opposite leg back.',
    'Hold for two seconds while keeping your hips level.',
    'Return and switch sides.',
  ]),
  E('hollow-hold', 'Hollow Body Hold', 'Core', 'Full Core', 'Advanced', 'hollow', t(3, 25, 40, 4), [
    'Lie on your back with arms overhead.',
    'Press your lower back into the floor.',
    'Lift your arms, shoulders and legs a few inches off the floor.',
    'Hold the banana shape and breathe steadily.',
  ]),
  E('v-ups', 'V-ups', 'Core', 'Abs, Hip Flexors', 'Advanced', 'vup', r(3, 12, 45, 6), [
    'Lie flat with arms overhead and legs straight.',
    'Simultaneously lift your torso and legs.',
    'Reach your hands toward your toes at the top.',
    'Lower back down with control.',
  ]),
  E('reverse-crunches', 'Reverse Crunches', 'Core', 'Lower Abs', 'Beginner', 'reversecrunch', r(3, 15, 30, 4), [
    'Lie on your back with knees bent at 90° and feet lifted.',
    'Curl your hips off the floor, bringing knees toward your chest.',
    'Pause briefly at the top.',
    'Lower your hips slowly.',
  ]),
  E('heel-touches', 'Heel Touches', 'Core', 'Obliques', 'Beginner', 'heeltouch', r(3, 20, 30, 3.5), [
    'Lie on your back with knees bent and feet flat.',
    'Lift your shoulders slightly off the floor.',
    'Reach one hand to touch the heel on the same side.',
    'Alternate sides in a side-to-side motion.',
  ]),
  E('sit-ups', 'Sit-ups', 'Core', 'Abs, Hip Flexors', 'Intermediate', 'situp', r(3, 15, 40, 5), [
    'Lie on your back with knees bent and arms crossed on your chest.',
    'Engage your abs and sit all the way up.',
    'Pause at the top with a tall spine.',
    'Lower down slowly one vertebra at a time.',
  ]),

  // ---------- CARDIO ----------
  E('jumping-jacks', 'Jumping Jacks', 'Cardio', 'Full Body, Calves', 'Beginner', 'jack', t(3, 40, 20, 8), [
    'Stand with feet together and arms at your sides.',
    'Jump your feet out while raising your arms overhead.',
    'Jump back to the starting position.',
    'Keep a steady, quick rhythm.',
  ]),
  E('high-knees', 'High Knees', 'Cardio', 'Hip Flexors, Quads, Calves', 'Beginner', 'highknees', t(3, 30, 30, 8), [
    'Stand tall with feet hip-width apart.',
    'Run in place, driving your knees up to hip height.',
    'Pump your arms in rhythm with your legs.',
    'Stay light on the balls of your feet.',
  ]),
  E('butt-kicks', 'Butt Kicks', 'Cardio', 'Hamstrings, Calves', 'Beginner', 'buttkick', t(3, 30, 30, 7), [
    'Stand tall and start jogging in place.',
    'Kick your heels up toward your glutes.',
    'Keep your thighs pointing down.',
    'Move your arms naturally.',
  ]),
  E('burpees', 'Burpees', 'Full Body', 'Full Body', 'Advanced', 'burpee', r(3, 10, 60, 8), [
    'Stand tall, then squat and place your hands on the floor.',
    'Jump your feet back into a plank (add a push-up if you like).',
    'Jump your feet back toward your hands.',
    'Explode up into a jump with arms overhead.',
  ], 'Scale by stepping back instead of jumping.'),
  E('skaters', 'Skater Jumps', 'Cardio', 'Glutes, Legs, Balance', 'Intermediate', 'skater', t(3, 30, 30, 7), [
    'Stand on your right leg with a slight knee bend.',
    'Leap sideways to land on your left leg.',
    'Swing the trailing leg behind you.',
    'Bound back and forth like a speed skater.',
  ]),
  E('shadow-boxing', 'Shadow Boxing', 'Cardio', 'Shoulders, Arms, Core', 'Beginner', 'punch', t(3, 45, 30, 7), [
    'Stand in a staggered stance with fists up by your chin.',
    'Throw quick straight punches, alternating arms.',
    'Rotate your torso slightly with each punch.',
    'Stay light on your feet and keep your guard up.',
  ]),
  E('jump-rope', 'Imaginary Jump Rope', 'Cardio', 'Calves, Shoulders', 'Beginner', 'jumprope', t(3, 45, 30, 8), [
    'Stand tall with elbows close to your sides.',
    'Rotate your wrists as if turning a rope.',
    'Hop lightly on the balls of your feet.',
    'Keep a steady rhythm — no rope needed.',
  ]),
  E('star-jumps', 'Star Jumps', 'Cardio', 'Full Body', 'Intermediate', 'jack', r(3, 12, 45, 8), [
    'Start in a quarter squat with arms low.',
    'Explode up, spreading arms and legs into a star shape.',
    'Bring limbs back in before landing.',
    'Land softly and repeat.',
  ]),
  E('squat-thrusts', 'Squat Thrusts', 'Cardio', 'Legs, Core, Shoulders', 'Intermediate', 'squatthrust', r(3, 12, 45, 8), [
    'Squat down and place your hands on the floor.',
    'Jump your feet back into a high plank.',
    'Jump your feet back toward your hands.',
    'Stand up and repeat.',
  ]),

  // ---------- FULL BODY ----------
  E('bear-crawl', 'Bear Crawl', 'Full Body', 'Shoulders, Core, Quads', 'Intermediate', 'bearcrawl', t(3, 30, 40, 7), [
    'Start on all fours with knees hovering an inch off the floor.',
    'Move your opposite hand and foot forward together.',
    'Keep your back flat and hips low.',
    'Crawl forward and back within your space.',
  ]),
  E('inchworms', 'Inchworms', 'Full Body', 'Hamstrings, Shoulders, Core', 'Beginner', 'inchworm', r(3, 8, 40, 5), [
    'Stand tall, then fold forward and place your hands on the floor.',
    'Walk your hands out into a high plank.',
    'Walk your hands back toward your feet.',
    'Roll up to standing.',
  ]),
  E('plank-jacks', 'Plank Jacks', 'Full Body', 'Core, Shoulders, Legs', 'Intermediate', 'plankjack', t(3, 30, 30, 7), [
    'Start in a high plank position.',
    'Jump your feet wide apart.',
    'Jump them back together.',
    'Keep your hips steady and core tight.',
  ]),

  // ---------- FLEXIBILITY ----------
  E('forward-fold', 'Standing Forward Fold', 'Flexibility', 'Hamstrings, Lower Back', 'Beginner', 'fold', t(2, 30, 10, 2.5), [
    'Stand tall and reach your arms overhead.',
    'Hinge at the hips and fold forward.',
    'Let your head and arms hang heavy.',
    'Bend your knees slightly if needed and breathe deeply.',
  ]),
  E('cobra-stretch', 'Cobra Stretch', 'Flexibility', 'Abs, Hip Flexors, Spine', 'Beginner', 'cobra', t(2, 30, 10, 2.5), [
    'Lie face down with hands under your shoulders.',
    'Press gently to lift your chest.',
    'Keep your hips on the floor and shoulders relaxed.',
    'Hold and breathe, then lower slowly.',
  ]),
  E('childs-pose', "Child's Pose", 'Flexibility', 'Back, Hips, Shoulders', 'Beginner', 'child', t(2, 40, 10, 2), [
    'Kneel and sit back on your heels.',
    'Fold forward and extend your arms in front of you.',
    'Rest your forehead on the floor.',
    'Breathe slowly into your back.',
  ]),
  E('cat-cow', 'Cat-Cow Stretch', 'Flexibility', 'Spine, Core', 'Beginner', 'catcow', t(2, 40, 10, 2.5), [
    'Start on all fours with a neutral spine.',
    'Inhale, drop your belly and lift your chest (cow).',
    'Exhale, round your spine toward the ceiling (cat).',
    'Flow slowly between the two positions.',
  ]),
  E('downward-dog', 'Downward Dog', 'Flexibility', 'Hamstrings, Calves, Shoulders', 'Beginner', 'downdog', t(2, 30, 10, 3), [
    'Start in a high plank.',
    'Push your hips up and back into an inverted V.',
    'Press your heels toward the floor.',
    'Keep your arms straight and head between your arms.',
  ]),
  E('hip-flexor-stretch', 'Kneeling Hip Flexor Stretch', 'Flexibility', 'Hip Flexors, Quads', 'Beginner', 'hipflexor', t(2, 30, 10, 2.5), [
    'Kneel on one knee with the other foot in front.',
    'Tuck your pelvis and shift your hips forward.',
    'Raise your arms overhead for a deeper stretch.',
    'Hold, then switch sides.',
  ]),
  E('quad-stretch', 'Standing Quad Stretch', 'Flexibility', 'Quads', 'Beginner', 'quadstretch', t(2, 30, 10, 2.3), [
    'Stand tall and hold a wall for balance if needed.',
    'Bend one knee and grab your foot behind you.',
    'Pull your heel gently toward your glutes.',
    'Keep knees together. Hold, then switch.',
  ]),
  E('butterfly-stretch', 'Butterfly Stretch', 'Flexibility', 'Inner Thighs, Hips', 'Beginner', 'seated', t(2, 40, 10, 2.3), [
    'Sit tall with the soles of your feet together.',
    'Hold your feet and let your knees drop outward.',
    'Gently press your knees toward the floor.',
    'Lean forward slightly for a deeper stretch.',
  ]),
  E('seated-hamstring', 'Seated Hamstring Stretch', 'Flexibility', 'Hamstrings, Lower Back', 'Beginner', 'hamstring', t(2, 30, 10, 2.3), [
    'Sit with both legs extended straight in front.',
    'Sit tall, then hinge forward from the hips.',
    'Reach toward your toes without rounding hard.',
    'Hold and breathe deeply.',
  ]),
  E('shoulder-stretch', 'Cross-Body Shoulder Stretch', 'Flexibility', 'Shoulders, Upper Back', 'Beginner', 'shoulderstretch', t(2, 30, 10, 2.3), [
    'Bring one arm straight across your chest.',
    'Use the other arm to gently pull it closer.',
    'Keep your shoulder down and relaxed.',
    'Hold, then switch arms.',
  ]),
];

export const EXERCISE_MAP = Object.fromEntries(EXERCISES.map((e) => [e.id, e]));

export const getExercise = (id) => EXERCISE_MAP[id];

/** Returns a human friendly target, e.g. "12 reps" or "30 sec" */
export const formatTarget = (item) =>
  item.type === 'time' ? `${item.duration} sec` : `${item.reps} reps`;
