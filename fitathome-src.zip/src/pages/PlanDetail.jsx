import { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Play, Clock, Flame, Dumbbell, Pencil, Copy, CalendarCheck, CalendarPlus, Timer, Layers } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageHeader, StatCard, Switch } from '../components/ui';
import ExerciseFigure from '../components/ExerciseFigure';
import ExerciseModal from '../components/ExerciseModal';
import { DayPills } from './Planner';
import NotFound from './NotFound';
import { getPlan } from '../utils/stats';
import { LEVELS } from '../data/plans';
import { EXERCISE_MAP } from '../data/exercises';
import { scaleItems, estimateDuration, estimateCalories } from '../utils/workout';
import { humanDuration } from '../utils/date';

export default function PlanDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { state, toggleSchedule, setPlanDays, toast } = useApp();
  const plan = getPlan(state, id);
  const [level, setLevel] = useState(state.profile.level || 'Intermediate');
  const [openEx, setOpenEx] = useState(null);
  if (!plan) return <NotFound />;

  const items = plan.builtIn ? scaleItems(plan.items, level, plan.level) : plan.items;
  const scheduled = state.scheduledPlanIds.includes(plan.id);
  const sessions = state.history.filter((h) => h.planId === plan.id).length;

  const toggleDay = (d) => {
    const days = plan.days.includes(d) ? plan.days.filter((x) => x !== d) : [...plan.days, d];
    setPlanDays(plan.id, days, plan.builtIn);
  };

  return (
    <>
      <button className="btn btn-sm btn-ghost mb-2" onClick={() => navigate(-1)}><ArrowLeft size={16} /> Back</button>
      <PageHeader
        eyebrow={`${plan.goal}${plan.builtIn ? ' · Predefined plan' : ' · Custom plan'}`}
        title={plan.name}
        subtitle={plan.description}
        actions={
          <>
            {plan.builtIn ? (
              <Link className="btn" to={`/builder?from=${plan.id}&level=${level}`}><Copy size={16} /> Customise</Link>
            ) : (
              <Link className="btn" to={`/builder/${plan.id}`}><Pencil size={16} /> Edit</Link>
            )}
            <button className="btn btn-primary" onClick={() => navigate(`/workout/${plan.id}${plan.builtIn ? `?level=${level}` : ''}`)}><Play size={16} /> Start workout</button>
          </>
        }
      />

      <div className="grid grid-4 mb-3">
        <StatCard icon={Dumbbell} label="Exercises" value={items.length} />
        <StatCard icon={Clock} label="Estimated time" value={humanDuration(estimateDuration(items))} color="#5ee7ff" />
        <StatCard icon={Flame} label="Estimated burn" value={`~${estimateCalories(items, state.profile.weightKg)}`} unit="kcal" color="#ff7a3d" />
        <StatCard icon={Layers} label="Sessions completed" value={sessions} color="#ffd23d" />
      </div>

      <div className="grid grid-3">
        <section className="card span-2">
          <div className="card-head wrap">
            <h2>Exercises</h2>
            {plan.builtIn && (
              <div className="tabs">
                {LEVELS.map((l) => <button key={l} className={level === l ? 'active' : ''} onClick={() => setLevel(l)}>{l}</button>)}
              </div>
            )}
          </div>
          <div className="list">
            {items.map((it, i) => {
              const ex = EXERCISE_MAP[it.exerciseId];
              return (
                <button key={`${it.exerciseId}-${i}`} className="list-item" style={{ background: 'none', border: 0, borderBottom: '1px solid var(--border)', width: '100%', textAlign: 'left', cursor: 'pointer' }} onClick={() => setOpenEx(ex)}>
                  <div className="figure-box" style={{ width: 72, flex: 'none', borderRadius: 12 }}><ExerciseFigure pose={ex.pose} animate={false} /></div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 600 }}>{i + 1}. {ex.name}</div>
                    <div className="tiny dim">{ex.muscle}</div>
                  </div>
                  <div style={{ textAlign: 'right' }} className="small">
                    <div className="num" style={{ fontWeight: 600 }}>{it.sets} × {it.duration != null ? `${it.duration}s` : `${it.reps} reps`}</div>
                    <div className="tiny dim row" style={{ justifyContent: 'flex-end', gap: 4 }}><Timer size={12} /> {it.rest}s rest</div>
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        <section className="card" style={{ alignSelf: 'start' }}>
          <h2 className="mb-2">Schedule</h2>
          <div className="row-between mb-2">
            <div className="row">
              {scheduled ? <CalendarCheck size={18} className="neon-text" /> : <CalendarPlus size={18} className="dim" />}
              <span>In my weekly schedule</span>
            </div>
            <Switch checked={scheduled} onChange={() => { toggleSchedule(plan.id); toast(scheduled ? 'Removed from schedule' : 'Added to schedule'); }} label="Add to schedule" />
          </div>
          <div className="label mb-1">Workout days</div>
          <DayPills days={plan.days} onToggle={toggleDay} />
          <p className="tiny dim mt-2">Scheduled days appear on your dashboard and calendar. Unscheduled days count as rest days and never break your streak.</p>
        </section>
      </div>

      {openEx && <ExerciseModal exercise={openEx} onClose={() => setOpenEx(null)} />}
    </>
  );
}
