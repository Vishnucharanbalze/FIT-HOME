import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Play, CheckCircle2, Moon, CalendarClock, XCircle, Flame, Clock } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageHeader } from '../components/ui';
import { historyByDay, plansForDate } from '../utils/stats';
import { toKey, addDays, startOfDay, startOfWeek, formatLongDate, formatTime } from '../utils/date';

const DOW = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export default function CalendarPage() {
  const { state } = useApp();
  const navigate = useNavigate();
  const [cursor, setCursor] = useState(() => new Date(new Date().getFullYear(), new Date().getMonth(), 1));
  const [selected, setSelected] = useState(() => toKey());
  const byDay = useMemo(() => historyByDay(state.history), [state.history]);
  const today = startOfDay(new Date());
  const todayK = toKey(today);

  const statusOf = (d) => {
    const k = toKey(d);
    const done = byDay[k] || [];
    const planned = plansForDate(state, d);
    if (done.length) return { kind: 'done', done, planned };
    if (planned.length && d < today) return { kind: 'missed', done, planned };
    if (planned.length) return { kind: 'scheduled', done, planned };
    return { kind: 'rest', done, planned };
  };

  const gridStart = startOfWeek(cursor);
  const cells = Array.from({ length: 42 }, (_, i) => addDays(gridStart, i));
  const month = cursor.getMonth();
  const lastRowNeeded = cells.slice(35).some((d) => d.getMonth() === month);
  const visible = lastRowNeeded ? cells : cells.slice(0, 35);

  const monthDays = visible.filter((d) => d.getMonth() === month);
  const summary = monthDays.reduce(
    (acc, d) => {
      const st = statusOf(d);
      acc[st.kind]++;
      acc.workouts += st.done.length;
      acc.minutes += st.done.reduce((a, h) => a + h.durationSec, 0) / 60;
      return acc;
    },
    { done: 0, missed: 0, scheduled: 0, rest: 0, workouts: 0, minutes: 0 }
  );

  const sel = statusOf(new Date(`${selected}T00:00:00`));
  const selDate = new Date(`${selected}T00:00:00`);

  return (
    <>
      <PageHeader eyebrow="Module 9" title="Workout Calendar" subtitle="See scheduled days, completed workouts and rest days at a glance." />
      <div className="grid grid-3">
        <section className="card span-2">
          <div className="row-between mb-2">
            <h2>{cursor.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}</h2>
            <div className="row">
              <button className="btn btn-sm" onClick={() => { setCursor(new Date(today.getFullYear(), today.getMonth(), 1)); setSelected(todayK); }}>Today</button>
              <button className="btn btn-icon sm" aria-label="Previous month" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}><ChevronLeft size={18} /></button>
              <button className="btn btn-icon sm" aria-label="Next month" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}><ChevronRight size={18} /></button>
            </div>
          </div>
          <div className="cal-grid">
            {DOW.map((d) => <div key={d} className="cal-dow">{d}</div>)}
            {visible.map((d) => {
              const k = toKey(d);
              const st = statusOf(d);
              const cls = ['cal-day', st.kind === 'rest' ? '' : st.kind, d.getMonth() !== month ? 'outside' : '', k === todayK ? 'today' : '', k === selected ? 'selected' : ''].join(' ');
              return (
                <button key={k} className={cls} onClick={() => setSelected(k)} aria-label={`${formatLongDate(d)}: ${st.kind}`}>
                  <span className="num" style={{ fontWeight: k === todayK ? 700 : 500 }}>{d.getDate()}</span>
                  <span className="dots">
                    {st.done.slice(0, 3).map((h) => <span key={h.id} className="dot" />)}
                    {st.kind === 'scheduled' && <span className="dot sched" />}
                    {st.kind === 'missed' && <span className="dot miss" />}
                  </span>
                </button>
              );
            })}
          </div>
          <div className="legend mt-2">
            <span><i style={{ background: 'linear-gradient(145deg, rgba(198,255,61,.5), rgba(61,255,139,.2))' }} /> Completed</span>
            <span><i style={{ border: '1.5px dashed var(--neon)' }} /> Scheduled</span>
            <span><i style={{ background: 'rgba(255,94,94,.2)', border: '1px solid rgba(255,94,94,.4)' }} /> Missed</span>
            <span><i style={{ border: '1px solid var(--border-strong)' }} /> Rest day</span>
          </div>
        </section>

        <div className="col" style={{ gap: 18 }}>
          <section className="card">
            <div className="eyebrow">{selected === todayK ? 'Today' : 'Selected day'}</div>
            <h2>{formatLongDate(selDate)}</h2>
            <div className="mt-2">
              {sel.kind === 'done' && <span className="badge neon"><CheckCircle2 size={13} /> Workout completed</span>}
              {sel.kind === 'missed' && <span className="badge" style={{ color: '#ff8b8b', background: 'rgba(255,94,94,.12)' }}><XCircle size={13} /> Missed</span>}
              {sel.kind === 'scheduled' && <span className="badge" style={{ color: 'var(--neon)' }}><CalendarClock size={13} /> Scheduled</span>}
              {sel.kind === 'rest' && <span className="badge"><Moon size={13} /> Rest day</span>}
            </div>

            {sel.done.length > 0 && (
              <div className="col mt-2" style={{ gap: 8 }}>
                <div className="label">Completed</div>
                {sel.done.map((h) => (
                  <div key={h.id} className="card" style={{ padding: 12, background: 'rgba(0,0,0,.25)', animation: 'none' }}>
                    <strong>{h.planName}</strong>
                    <div className="row tiny dim mt-1 wrap">
                      <span>{formatTime(h.date)}</span>
                      <span className="row" style={{ gap: 3 }}><Clock size={12} /> {Math.round(h.durationSec / 60)} min</span>
                      <span className="row" style={{ gap: 3 }}><Flame size={12} /> {h.calories} kcal</span>
                      <span>{h.exercisesCompleted}/{h.totalExercises} exercises</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {sel.planned.length > 0 && (
              <div className="col mt-2" style={{ gap: 8 }}>
                <div className="label">Planned</div>
                {sel.planned.map((p) => (
                  <div key={p.id} className="row-between" style={{ padding: '8px 0' }}>
                    <span className="row" style={{ minWidth: 0 }}><span className="plan-color" style={{ background: p.color, color: p.color }} /><span className="truncate">{p.name}</span></span>
                    {selected === todayK ? (
                      <button className="btn btn-primary btn-sm" onClick={() => navigate(`/workout/${p.id}${p.builtIn ? `?level=${state.profile.level}` : ''}`)}><Play size={14} /> Start</button>
                    ) : (
                      <button className="btn btn-sm" onClick={() => navigate(`/plans/${p.id}`)}>View</button>
                    )}
                  </div>
                ))}
              </div>
            )}
            {sel.kind === 'rest' && !sel.done.length && <p className="small muted mt-2">No workout scheduled. Recovery is part of progress — try a stretch or a walk.</p>}
          </section>

          <section className="card">
            <h3 className="mb-2">This month</h3>
            <div className="grid grid-2" style={{ gap: 10 }}>
              <MiniStat label="Workout days" value={summary.done} color="var(--neon)" />
              <MiniStat label="Workouts" value={summary.workouts} color="#3dff8b" />
              <MiniStat label="Minutes" value={Math.round(summary.minutes)} color="#5ee7ff" />
              <MiniStat label="Missed" value={summary.missed} color="#ff8b8b" />
              <MiniStat label="Upcoming" value={summary.scheduled} color="#ffd23d" />
              <MiniStat label="Rest days" value={summary.rest} color="var(--text-2)" />
            </div>
          </section>
        </div>
      </div>
    </>
  );
}

function MiniStat({ label, value, color }) {
  return (
    <div style={{ padding: 12, borderRadius: 14, background: 'rgba(0,0,0,.25)', border: '1px solid var(--border)' }}>
      <div className="num" style={{ fontSize: '1.4rem', fontWeight: 700, color }}>{value}</div>
      <div className="tiny dim">{label}</div>
    </div>
  );
}
