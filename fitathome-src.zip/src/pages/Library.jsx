import { useMemo, useState } from 'react';
import { Search, Repeat, Timer, X } from 'lucide-react';
import { PageHeader, Empty } from '../components/ui';
import ExerciseFigure from '../components/ExerciseFigure';
import ExerciseModal from '../components/ExerciseModal';
import { EXERCISES, CATEGORIES, DIFFICULTIES, formatTarget } from '../data/exercises';

export default function Library() {
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('All');
  const [diff, setDiff] = useState('All');
  const [hover, setHover] = useState(null);
  const [open, setOpen] = useState(null);

  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    return EXERCISES.filter(
      (e) =>
        (cat === 'All' || e.category === cat) &&
        (diff === 'All' || e.difficulty === diff) &&
        (!s || `${e.name} ${e.muscle} ${e.category}`.toLowerCase().includes(s))
    );
  }, [q, cat, diff]);

  return (
    <>
      <PageHeader
        eyebrow="Module 3"
        title="Exercise Library"
        subtitle={`${EXERCISES.length} home exercises with animated demos, form cues and recommended sets. No equipment needed.`}
      />

      <div className="card mb-3" style={{ padding: 14 }}>
        <div className="row wrap" style={{ gap: 12 }}>
          <div className="input-group" style={{ flex: '1 1 260px' }}>
            <Search size={17} />
            <input className="input" placeholder="Search exercises or muscles (e.g. glutes)…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search exercises" />
            {q && <button className="btn btn-icon sm btn-ghost" style={{ position: 'absolute', right: 4, top: 4 }} onClick={() => setQ('')} aria-label="Clear search"><X size={15} /></button>}
          </div>
          <select className="select" style={{ width: 'auto', minWidth: 170 }} value={diff} onChange={(e) => setDiff(e.target.value)} aria-label="Difficulty filter">
            <option value="All">All difficulties</option>
            {DIFFICULTIES.map((d) => <option key={d}>{d}</option>)}
          </select>
        </div>
        <div className="chips scroll mt-2">
          {['All', ...CATEGORIES].map((c) => (
            <button key={c} className={`chip${cat === c ? ' active' : ''}`} onClick={() => setCat(c)}>
              {c} <span style={{ opacity: 0.6 }}>{c === 'All' ? EXERCISES.length : EXERCISES.filter((e) => e.category === c).length}</span>
            </button>
          ))}
        </div>
      </div>

      <p className="small dim mb-2">Showing {list.length} exercise{list.length === 1 ? '' : 's'} · hover or tap a card for the full demo</p>

      {list.length === 0 ? (
        <div className="card"><Empty icon={Search} title="No matches" text="Try a different search or filter." /></div>
      ) : (
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))' }}>
          {list.map((e) => (
            <article
              key={e.id}
              className="card hover ex-card"
              onMouseEnter={() => setHover(e.id)}
              onMouseLeave={() => setHover(null)}
              onClick={() => setOpen(e)}
              tabIndex={0}
              onKeyDown={(ev) => ev.key === 'Enter' && setOpen(e)}
              role="button"
              aria-label={`${e.name} details`}
            >
              <div className="figure-box"><ExerciseFigure pose={e.pose} animate={hover === e.id} title={e.name} /></div>
              <div>
                <h3>{e.name}</h3>
                <div className="tiny dim truncate">{e.muscle}</div>
              </div>
              <div className="row-between">
                <span className={`badge ${e.difficulty}`}>{e.difficulty}</span>
                <span className="tiny muted row" style={{ gap: 4 }}>
                  {e.type === 'time' ? <Timer size={12} /> : <Repeat size={12} />}
                  {e.sets} × {formatTarget(e)}
                </span>
              </div>
            </article>
          ))}
        </div>
      )}
      {open && <ExerciseModal exercise={open} onClose={() => setOpen(null)} />}
    </>
  );
}
