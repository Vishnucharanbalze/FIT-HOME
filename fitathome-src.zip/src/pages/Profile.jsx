import { useRef, useState } from 'react';
import { Save, UserRound, Settings2, Database, Download, Upload, RotateCcw, Trash2, PlayCircle, ShieldCheck, Smartphone, Volume2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageHeader, Switch } from '../components/ui';
import Modal from '../components/Modal';
import { GOALS, LEVELS } from '../data/plans';
import { bmiInfo } from '../utils/stats';
import { useInstallPrompt } from '../utils/pwa';
import { sounds, speak, unlockAudio } from '../utils/audio';

export default function Profile() {
  const { state, updateProfile, updatePreferences, loadDemo, clearAll, exportData, importData, toast } = useApp();
  const [form, setForm] = useState(state.profile);
  const [confirm, setConfirm] = useState(null);
  const fileRef = useRef(null);
  const { canInstall, install } = useInstallPrompt();
  const prefs = state.preferences;
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const dirty = JSON.stringify(form) !== JSON.stringify(state.profile);

  const save = (e) => {
    e.preventDefault();
    const age = Number(form.age);
    const h = Number(form.heightCm);
    const w = Number(form.weightKg);
    if (!String(form.name).trim()) return toast('Please enter your name', 'error');
    if (form.age !== '' && (age < 10 || age > 100)) return toast('Age should be between 10 and 100', 'error');
    if (h < 80 || h > 250) return toast('Height should be between 80 and 250 cm', 'error');
    if (w < 20 || w > 350) return toast('Weight should be between 20 and 350 kg', 'error');
    const clean = { ...form, name: form.name.trim(), age: form.age === '' ? '' : age, heightCm: h, weightKg: w, duration: Number(form.duration) };
    updateProfile(clean);
    setForm(clean);
    toast('Profile saved');
  };

  const info = bmiInfo(form.heightCm, form.weightKg);

  const onImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      await importData(file);
      window.location.reload();
    } catch (err) {
      toast(err.message || 'Import failed', 'error');
    }
    e.target.value = '';
  };

  return (
    <>
      <PageHeader eyebrow="Module 10" title="Profile & Settings" subtitle="Your details personalise plans, calorie estimates and goals." />

      <div className="grid grid-3">
        <form className="card span-2" onSubmit={save}>
          <div className="row mb-3">
            <div className="avatar" style={{ width: 64, height: 64, borderRadius: 20, fontSize: '1.6rem' }}>{(form.name || 'A').charAt(0).toUpperCase()}</div>
            <div>
              <h2>{form.name || 'Your name'}</h2>
              <div className="small dim">{form.level} · {form.goal}{info ? ` · BMI ${info.bmi}` : ''}</div>
            </div>
          </div>
          <div className="form-grid">
            <div className="field">
              <label className="label" htmlFor="name">Full name</label>
              <input id="name" className="input" value={form.name} onChange={set('name')} placeholder="Your name" />
            </div>
            <div className="field">
              <label className="label" htmlFor="age">Age</label>
              <input id="age" type="number" className="input" value={form.age} onChange={set('age')} placeholder="e.g. 21" />
            </div>
            <div className="field">
              <label className="label" htmlFor="gender">Gender (optional)</label>
              <select id="gender" className="select" value={form.gender || ''} onChange={set('gender')}>
                <option value="">Prefer not to say</option>
                <option>Male</option>
                <option>Female</option>
                <option>Other</option>
              </select>
            </div>
            <div className="field">
              <label className="label" htmlFor="dur">Preferred workout duration</label>
              <select id="dur" className="select" value={form.duration} onChange={set('duration')}>
                {[10, 15, 20, 30, 45, 60, 90].map((m) => <option key={m} value={m}>{m} minutes</option>)}
              </select>
            </div>
            <div className="field">
              <label className="label" htmlFor="height">Height (cm)</label>
              <input id="height" type="number" className="input" value={form.heightCm} onChange={set('heightCm')} />
            </div>
            <div className="field">
              <label className="label" htmlFor="weight">Weight (kg)</label>
              <input id="weight" type="number" step="0.1" className="input" value={form.weightKg} onChange={set('weightKg')} />
            </div>
            <div className="field">
              <label className="label" htmlFor="goal">Fitness goal</label>
              <select id="goal" className="select" value={form.goal} onChange={set('goal')}>
                {GOALS.map((g) => <option key={g}>{g}</option>)}
              </select>
            </div>
            <div className="field">
              <label className="label" htmlFor="level">Fitness level</label>
              <select id="level" className="select" value={form.level} onChange={set('level')}>
                {LEVELS.map((g) => <option key={g}>{g}</option>)}
              </select>
            </div>
          </div>
          <div className="row mt-3" style={{ justifyContent: 'flex-end' }}>
            {dirty && <button type="button" className="btn btn-ghost" onClick={() => setForm(state.profile)}>Discard</button>}
            <button type="submit" className="btn btn-primary" disabled={!dirty}><Save size={16} /> Save profile</button>
          </div>
        </form>

        <section className="card" style={{ alignSelf: 'start' }}>
          <h2 className="row mb-2"><Settings2 size={20} className="neon-text" /> Workout preferences</h2>
          <div className="col" style={{ gap: 16 }}>
            <Pref label="Beep sounds" sub="Countdown beeps and transitions" checked={prefs.sound} onChange={(v) => updatePreferences({ sound: v })} />
            <Pref label="Voice coach" sub="Announces exercises and rest" checked={prefs.voice} onChange={(v) => updatePreferences({ voice: v })} />
            <Pref label="Vibration" sub="On supported phones" checked={prefs.vibrate} onChange={(v) => updatePreferences({ vibrate: v })} />
            <Pref label="Auto-advance rep sets" sub="Move on when the set timer ends" checked={prefs.autoAdvance} onChange={(v) => updatePreferences({ autoAdvance: v })} />
            <div className="row-between">
              <div><div style={{ fontWeight: 500 }}>Get-ready countdown</div><div className="tiny dim">Before the first exercise</div></div>
              <select className="select" style={{ width: 96 }} value={prefs.countdown} onChange={(e) => updatePreferences({ countdown: Number(e.target.value) })}>
                {[3, 5, 10, 15].map((s) => <option key={s} value={s}>{s}s</option>)}
              </select>
            </div>
            <button className="btn btn-sm" type="button" onClick={() => { unlockAudio(); sounds.go(); if (prefs.voice) speak('Sound check. Let’s go!'); }}><Volume2 size={15} /> Test sound</button>
          </div>
        </section>
      </div>

      <div className="grid grid-2 mt-3">
        <section className="card">
          <h2 className="row mb-1"><PlayCircle size={20} style={{ color: 'var(--cyan)' }} /> Demo mode</h2>
          <p className="small muted mb-2">Load a complete sample profile (“Arjun Sharma”) with ~10 weeks of realistic workout history, water logs, measurements and custom plans — perfect for presentations.</p>
          <div className="row wrap">
            <button className="btn btn-primary" onClick={() => setConfirm('demo')}><RotateCcw size={16} /> {state.demoMode ? 'Reset demo data' : 'Load demo data'}</button>
            <button className="btn btn-danger" onClick={() => setConfirm('clear')}><Trash2 size={16} /> Clear all data</button>
          </div>
          <p className="tiny dim mt-2">Status: {state.demoMode ? 'Demo mode is ON' : 'Using your own data'} · {state.history.length} workouts stored</p>
        </section>

        <section className="card">
          <h2 className="row mb-1"><Database size={20} style={{ color: 'var(--amber)' }} /> Your data</h2>
          <p className="small muted mb-2">Everything is saved in this browser’s <span className="kbd">localStorage</span> and survives refreshes and restarts. It is <strong>not</strong> synced between devices or browsers — use a backup file to move it.</p>
          <div className="row wrap">
            <button className="btn" onClick={exportData}><Download size={16} /> Export backup</button>
            <button className="btn" onClick={() => fileRef.current?.click()}><Upload size={16} /> Import backup</button>
            <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={onImport} />
          </div>
          <div className="row small dim mt-2"><ShieldCheck size={15} /> No accounts, no servers, no tracking. Your data never leaves this device.</div>
          <div className="row small dim mt-1">
            <Smartphone size={15} /> Install as an app for offline use.
            {canInstall && <button className="btn btn-sm" onClick={install}>Install</button>}
          </div>
        </section>
      </div>

      {confirm && (
        <Modal size="sm" title={confirm === 'demo' ? 'Load demo data?' : 'Clear all data?'} onClose={() => setConfirm(null)}>
          <p className="muted">
            {confirm === 'demo'
              ? 'Your current profile, history and plans in this browser will be replaced by the sample demo account.'
              : 'This permanently deletes your profile, history, plans, water and measurements from this browser. Consider exporting a backup first.'}
          </p>
          <div className="row mt-3" style={{ justifyContent: 'flex-end' }}>
            <button className="btn" onClick={() => setConfirm(null)}>Cancel</button>
            <button
              className={confirm === 'demo' ? 'btn btn-primary' : 'btn btn-danger'}
              onClick={() => {
                if (confirm === 'demo') loadDemo(); else clearAll();
                setConfirm(null);
                setTimeout(() => window.location.reload(), 300);
              }}
            >
              {confirm === 'demo' ? 'Load demo' : 'Delete everything'}
            </button>
          </div>
        </Modal>
      )}
    </>
  );
}

function Pref({ label, sub, checked, onChange }) {
  return (
    <div className="row-between">
      <div><div style={{ fontWeight: 500 }}>{label}</div><div className="tiny dim">{sub}</div></div>
      <Switch checked={!!checked} onChange={onChange} label={label} />
    </div>
  );
}
