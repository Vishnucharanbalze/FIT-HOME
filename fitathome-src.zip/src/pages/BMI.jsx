import { useMemo, useState } from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceArea } from 'recharts';
import { Scale, Save, Info, AlertTriangle, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageHeader, ChartTooltip } from '../components/ui';
import { bmiInfo } from '../utils/stats';
import { formatDate } from '../utils/date';

const CATEGORIES = [
  { range: 'Below 18.5', label: 'Underweight', color: '#5ee7ff', text: 'May indicate low energy intake or other factors. Focus on balanced nutrition and strength training.' },
  { range: '18.5 – 24.9', label: 'Healthy weight', color: '#3dff8b', text: 'Associated with lower risk of weight-related health problems for most adults.' },
  { range: '25 – 29.9', label: 'Overweight', color: '#ffd23d', text: 'Regular activity and mindful eating can help. Muscle mass can also push BMI up.' },
  { range: '30 and above', label: 'Obesity', color: '#ff5e5e', text: 'Higher risk of some health conditions. A doctor can help build a safe plan.' },
];

export default function BMI() {
  const { state, addMeasurement, deleteMeasurement, toast } = useApp();
  const [unit, setUnit] = useState('metric');
  const [heightCm, setHeightCm] = useState(state.profile.heightCm || 170);
  const [weightKg, setWeightKg] = useState(state.profile.weightKg || 70);

  const ftIn = { ft: Math.floor(heightCm / 30.48), in: Math.round((heightCm / 2.54) % 12) };
  const lb = Math.round(weightKg * 2.20462 * 10) / 10;
  const info = bmiInfo(heightCm, weightKg);
  const valid = heightCm >= 80 && heightCm <= 250 && weightKg >= 20 && weightKg <= 350;
  const markerPos = info ? Math.max(0, Math.min(100, ((info.bmi - 12) / (42 - 12)) * 100)) : 0;

  const chart = useMemo(
    () => [...state.measurements].sort((a, b) => (a.date < b.date ? -1 : 1)).map((m) => ({ label: formatDate(m.date), weight: m.weightKg, bmi: bmiInfo(m.heightCm, m.weightKg)?.bmi, id: m.id })),
    [state.measurements]
  );

  const save = () => {
    if (!valid) return toast('Please enter a realistic height and weight', 'error');
    addMeasurement({ heightCm: Math.round(heightCm * 10) / 10, weightKg: Math.round(weightKg * 10) / 10 });
    toast('Measurements saved to your profile');
  };

  return (
    <>
      <PageHeader eyebrow="Module 7" title="BMI Calculator" subtitle="Check your Body Mass Index and track your weight over time." />

      <div className="grid grid-3 mb-3">
        <section className="card">
          <div className="row-between mb-2">
            <h2 className="row"><Scale size={20} className="neon-text" /> Your measurements</h2>
          </div>
          <div className="tabs mb-2">
            <button className={unit === 'metric' ? 'active' : ''} onClick={() => setUnit('metric')}>Metric</button>
            <button className={unit === 'imperial' ? 'active' : ''} onClick={() => setUnit('imperial')}>Imperial</button>
          </div>
          {unit === 'metric' ? (
            <div className="col" style={{ gap: 14 }}>
              <div className="field">
                <label className="label" htmlFor="h">Height</label>
                <div className="input-group" style={{ position: 'relative' }}>
                  <input id="h" type="number" className="input" style={{ paddingLeft: 14 }} value={heightCm} min={80} max={250} onChange={(e) => setHeightCm(Number(e.target.value))} />
                  <span className="input-suffix">cm</span>
                </div>
              </div>
              <div className="field">
                <label className="label" htmlFor="w">Weight</label>
                <div style={{ position: 'relative' }}>
                  <input id="w" type="number" step="0.1" className="input" value={weightKg} min={20} max={350} onChange={(e) => setWeightKg(Number(e.target.value))} />
                  <span className="input-suffix">kg</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="col" style={{ gap: 14 }}>
              <div className="field">
                <span className="label">Height</span>
                <div className="row">
                  <div style={{ position: 'relative', flex: 1 }}>
                    <input type="number" className="input" aria-label="Feet" value={ftIn.ft} onChange={(e) => setHeightCm(Number(e.target.value) * 30.48 + ftIn.in * 2.54)} />
                    <span className="input-suffix">ft</span>
                  </div>
                  <div style={{ position: 'relative', flex: 1 }}>
                    <input type="number" className="input" aria-label="Inches" value={ftIn.in} onChange={(e) => setHeightCm(ftIn.ft * 30.48 + Number(e.target.value) * 2.54)} />
                    <span className="input-suffix">in</span>
                  </div>
                </div>
              </div>
              <div className="field">
                <label className="label" htmlFor="lb">Weight</label>
                <div style={{ position: 'relative' }}>
                  <input id="lb" type="number" className="input" value={lb} onChange={(e) => setWeightKg(Number(e.target.value) / 2.20462)} />
                  <span className="input-suffix">lb</span>
                </div>
              </div>
            </div>
          )}
          <button className="btn btn-primary btn-block mt-2" onClick={save} disabled={!valid}><Save size={16} /> Save & update profile</button>
          {!valid && <p className="tiny mt-1" style={{ color: 'var(--red)' }}>Enter height 80–250 cm and weight 20–350 kg.</p>}
        </section>

        <section className="card span-2">
          <h2 className="mb-2">Your result</h2>
          {info && valid ? (
            <>
              <div className="row wrap" style={{ gap: 28, alignItems: 'flex-end' }}>
                <div>
                  <div className="num" style={{ fontSize: '4rem', fontWeight: 700, lineHeight: 1, color: info.color, textShadow: `0 0 30px ${info.color}55` }}>{info.bmi}</div>
                  <div className="small dim">BMI (kg/m²)</div>
                </div>
                <div>
                  <span className="badge" style={{ color: info.color, background: `${info.color}22`, fontSize: '0.9rem', padding: '6px 12px' }}>{info.category}</span>
                  <p className="small muted mt-1">Healthy weight range for your height: <strong className="num">{info.healthyMin.toFixed(1)} – {info.healthyMax.toFixed(1)} kg</strong></p>
                </div>
              </div>
              <div className="mt-3">
                <div className="bmi-scale"><div className="bmi-marker" style={{ left: `${markerPos}%` }} /></div>
                <div className="bmi-ticks"><span>12</span><span>18.5</span><span>25</span><span>30</span><span>42</span></div>
              </div>
            </>
          ) : (
            <p className="muted">Enter your height and weight to calculate BMI.</p>
          )}
          <div className="grid grid-2 mt-3" style={{ gap: 10 }}>
            {CATEGORIES.map((c) => (
              <div key={c.label} style={{ padding: 12, borderRadius: 14, border: `1px solid ${info?.category === c.label ? c.color : 'var(--border)'}`, background: info?.category === c.label ? `${c.color}12` : 'rgba(0,0,0,.2)' }}>
                <div className="row-between"><strong style={{ color: c.color }}>{c.label}</strong><span className="tiny dim num">{c.range}</span></div>
                <p className="tiny muted mt-1">{c.text}</p>
              </div>
            ))}
          </div>
        </section>
      </div>

      <div className="grid grid-3">
        <section className="card span-2">
          <div className="card-head"><div><h2>Weight trend</h2><div className="card-sub">Each saved measurement (one per day)</div></div></div>
          {chart.length < 2 ? (
            <p className="muted small">Save measurements on different days to see your trend.</p>
          ) : (
            <div style={{ height: 250 }}>
              <ResponsiveContainer>
                <LineChart data={chart} margin={{ top: 8, right: 8, left: -14, bottom: 0 }}>
                  <CartesianGrid vertical={false} />
                  <XAxis dataKey="label" tickLine={false} axisLine={false} />
                  <YAxis domain={['dataMin - 1', 'dataMax + 1']} tickLine={false} axisLine={false} />
                  {info && <ReferenceArea y1={info.healthyMin} y2={info.healthyMax} fill="#3dff8b" fillOpacity={0.05} />}
                  <Tooltip content={<ChartTooltip units={{ weight: 'kg' }} />} />
                  <Line type="monotone" dataKey="weight" name="weight" stroke="#c6ff3d" strokeWidth={2.5} dot={{ r: 4, fill: '#c6ff3d' }} />
                  <Line type="monotone" dataKey="bmi" name="BMI" stroke="#5ee7ff" strokeWidth={0} dot={false} activeDot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
          {chart.length > 0 && (
            <div className="chips mt-2">
              {[...chart].reverse().slice(0, 6).map((m) => (
                <span key={m.id} className="chip" style={{ cursor: 'default' }}>
                  {m.label}: <strong className="num">{m.weight} kg</strong>
                  <button className="btn btn-ghost" style={{ padding: 0, border: 0, marginLeft: 6, background: 'none' }} aria-label="Delete measurement" onClick={() => deleteMeasurement(m.id)}><Trash2 size={12} /></button>
                </span>
              ))}
            </div>
          )}
        </section>

        <section className="card">
          <h2 className="row mb-2"><Info size={20} style={{ color: 'var(--cyan)' }} /> What is BMI?</h2>
          <p className="small muted">Body Mass Index is your weight in kilograms divided by your height in metres squared (kg/m²). It is a quick way to compare weight to height across large groups of adults.</p>
          <p className="small muted mt-1">It does <strong>not</strong> measure body fat directly, and it can’t tell muscle from fat — athletes often score “overweight” while being very fit. It also doesn’t account for age, sex, ethnicity or where fat is stored.</p>
          <div className="note mt-2"><AlertTriangle size={16} /> BMI is a rough screening measure, not a medical diagnosis. Talk to a doctor or qualified health professional for advice about your health.</div>
        </section>
      </div>
    </>
  );
}
