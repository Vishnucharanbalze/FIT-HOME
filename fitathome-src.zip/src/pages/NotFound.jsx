import { Link } from 'react-router-dom';
import { Compass } from 'lucide-react';
import { Empty } from '../components/ui';

export default function NotFound() {
  return (
    <div className="card">
      <Empty icon={Compass} title="Page not found" text="That page or plan doesn't exist (it may have been deleted)." action={<Link to="/" className="btn btn-primary">Back to dashboard</Link>} />
    </div>
  );
}
