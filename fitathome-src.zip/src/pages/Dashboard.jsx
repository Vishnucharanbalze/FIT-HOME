import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ResponsiveContainer, ComposedChart, Bar as RBar, Line, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import {
  Flame, Trophy, Zap, Target, Play, Clock, Dumbbell, RefreshCw, Droplets, Plus, ChevronRight, Moon, CheckCircle2, Quote,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { StatCard, ProgressRing, ChartTooltip } from '../components/ui';
import { greeting, formatLongDate, humanDuration, todayKey, formatDate, formatTime } from '../utils/date';
import { plansForDate, currentStreak, totals, dailySeries, weekCompletion, minutesToday, caloriesToday, getPlan } from '../utils/stats';
import { scaleItems, estimateDuration, estimateCalories } from '../utils/workout';
import { quoteOfTheDay } from '../data/quotes';

export default function Dashboard() {
  const { state, addWater } = useApp();
  const navigate = useNavigate();
  const [quoteOffset, setQuoteOffset] = useState(0);
  const { profile, history } = state;

  const today = new Date();
  const todaysPlans = plansForDate(state, today);
  const doneToday = history.filter((h) => h.dayKey === todayKey());
  const t = totals(history);
  const streak = currentStreak(state);
  const week = weekCompletion(state);
  const series = useMemo(() => dailySeries(history, 7), [history]);
  const weekCalories = series.reduce((a, d) => a + d.calories, 0);
  const minsToday = minutesToday(history);
  const goalPct = Math.min(100, Math.round((minsToday / (profile.duration || 30)) * 100));
  const quote = quoteOfTheDay(quoteOffset);

  const waterToday = (state.water.logs[todayKey()] || []).reduce((a, w) => a + w.ml, 0);
  const waterPct = Math.min(100, Math.round((waterToday / state.water.goalMl) * 100));

  const recent = [...history].sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, 5);
  const firstName = (profile.name || 'Athlete').split(' ')[0];

  return (
    <div className="grid stagger">
      {/* Hero */}
      <div className="grid grid-3">
        <section className="card neon span-2" style={{ display: 'flex', gap: 24, alignItems: 'center', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: 240 }}>
            <div className="eyebrow">{formatLongDate(today)}</div>
            <h1 className="hero-title">{greeting()}, {firstName} 👋</h1>
            <p className="muted mt-1">
              {doneToday.length
                ? `Great job — ${doneToday.length} workout${doneToday.length > 1 ? 's' : ''} done today. Keep the momentum!`
                : todaysPlans.length
                  ? `You have ${todaysPlans.length} workout${todaysPlans.length > 1 ? 's' : ''} planned today. Let's crush it!`
                  : 'Today is a rest day. Stretch, hydrate and recover.'}
            </p>
            <div className="card mt-2" style={{ padding: '14px 16px', background: 'rgba(0,0,0,.25)' }}>
              <div className="row-between">
                <div className="row small neon-text" style={{ fontWeight: 600 }}><Quote size={15} /> {quote.tag}</div>
                <button className="btn btn-icon sm btn-ghost" onClick={() => setQuoteOffset((o) => o + 1)} aria-label="Next motivational message"><RefreshCw size={15} /></button>
              </div>
              <p className="mt-1" style={{ fontSize: '1.02rem', fontWeight: 500 }}>“{quote.text}”</p>
            </div>
          </div>
        </section>

        <section className="card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12 }}>
          <div className="row-between" style={{ width: '100%' }}>
            <h3 className="row"><Target size={18} className="neon-text" /> Daily goal</h3>
            <span className="badge neon">{profile.duration} min</span>
          </div>
          <ProgressRing value={goalPct} size={150}>
            <div>
              <div className="num" style={{ fontSize: '2rem', fontWeight: 700 }}>{goalPct}%</div>
              <div className="tiny dim">{minsToday} / {profile.duration} min</div>
            </div>
          </ProgressRing>
          <p className="small muted">{goalPct >= 100 ? 'Goal smashed! 🎉' : `${Math.max(0, profile.duration - minsToday)} min to go · ${caloriesToday(history)} kcal today`}</p>
        </section>
      </div>

      {/* Stats */}
      <div className="grid grid-4">
        <StatCard icon={Dumbbell} label="Workouts completed" value={t.workouts} trend={`${t.minutes} total minutes`} />
        <StatCard icon={Flame} label="Calories burned (est.)" value={t.calories.toLocaleString()} unit="kcal" trend={`${weekCalories} kcal this week`} color="#ff7a3d" />
        <StatCard icon={Zap} label="Current streak" value={streak} unit={streak === 1 ? 'day' : 'days'} trend={streak ? 'Keep it alive!' : 'Start today'} color="#ffd23d" />
        <StatCard icon={Trophy} label="Weekly completion" value={`${week.pct}%`} trend={`${week.done} of ${week.scheduled} sessions`} color="#5ee7ff" />
      </div>

      {/* Today + chart */}
      <div className="grid grid-3">
        <section className="card">
          <div className="card-head">
            <h2>Today's workout</h2>
            <Link to="/calendar" className="small dim row">Calendar <ChevronRight size={14} /></Link>
          </div>
          {todaysPlans.length === 0 ? (
            <div className="empty" style={{ padding: '18px 0' }}>
              <Moon size={36} />
              <h3 style={{ color: 'var(--text)' }}>Rest day</h3>
              <p className="small">Nothing scheduled. A light stretch helps recovery.</p>
              <button className="btn btn-sm" onClick={() => navigate('/plans/flexibility')}>Try Flexibility Flow</button>
            </div>
          ) : (
            <div className="col" style={{ gap: 12 }}>
              {todaysPlans.map((p) => {
                const items = p.builtIn ? scaleItems(p.items, profile.level, p.level) : p.items;
                const done = doneToday.some((h) => h.planId === p.id);
                return (
                  <div key={p.id} className="card" style={{ padding: 14, background: 'rgba(0,0,0,.25)' }}>
                    <div className="row-between">
                      <div className="row" style={{ minWidth: 0 }}>
                        <span className="plan-color" style={{ background: p.color, color: p.color }} />
                        <strong className="truncate">{p.name}</strong>
                      </div>
                      {done && <span className="badge neon"><CheckCircle2 size={12} /> Done</span>}
                    </div>
                    <div className="row small dim mt-1 wrap">
                      <span className="row" style={{ gap: 4 }}><Dumbbell size={13} /> {items.length} exercises</span>
                      <span className="row" style={{ gap: 4 }}><Clock size={13} /> {humanDuration(estimateDuration(items))}</span>
                      <span className="row" style={{ gap: 4 }}><Flame size={13} /> ~{estimateCalories(items, profile.weightKg)} kcal</span>
                    </div>
                    <div className="row mt-2">
                      <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={() => navigate(`/workout/${p.id}${p.builtIn ? `?level=${profile.level}` : ''}`)}>
                        <Play size={14} /> {done ? 'Do it again' : 'Start workout'}
                      </button>
                      <button className="btn btn-sm" onClick={() => navigate(`/plans/${p.id}`)}>Details</button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        <section className="card span-2">
          <div className="card-head">
            <div>
              <h2>Weekly activity</h2>
              <div className="card-sub">Minutes trained and calories burned — last 7 days</div>
            </div>
            <Link to="/progress" className="btn btn-sm">Full analytics</Link>
          </div>
          <div style={{ width: '100%', height: 260 }}>
            <ResponsiveContainer>
              <ComposedChart data={series} margin={{ top: 8, right: 4, left: -18, bottom: 0 }}>
                <defs>
                  <linearGradient id="barG" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0" stopColor="#c6ff3d" stopOpacity={1} />
                    <stop offset="1" stopColor="#3dff8b" stopOpacity={0.35} />
                  </linearGradient>
                </defs>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="label" tickLine={false} axisLine={false} />
                <YAxis yAxisId="m" tickLine={false} axisLine={false} />
                <YAxis yAxisId="c" orientation="right" hide />
                <Tooltip content={<ChartTooltip units={{ minutes: 'min', calories: 'kcal' }} />} cursor={{ fill: 'rgba(255,255,255,.04)' }} />
                <RBar yAxisId="m" dataKey="minutes" name="minutes" fill="url(#barG)" radius={[8, 8, 4, 4]} maxBarSize={38} />
                <Line yAxisId="c" dataKey="calories" name="calories" type="monotone" stroke="#ff7a3d" strokeWidth={2.5} dot={{ r: 3, fill: '#ff7a3d' }} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </section>
      </div>

      {/* Water + recent */}
      <div className="grid grid-3">
        <section className="card">
          <div className="card-head">
            <h2 className="row"><Droplets size={20} style={{ color: 'var(--cyan)' }} /> Hydration</h2>
            <Link to="/water" className="small dim row">Open <ChevronRight size={14} /></Link>
          </div>
          <div className="row-between mb-1">
            <span className="num" style={{ fontSize: '1.6rem', fontWeight: 700 }}>{(waterToday / 1000).toFixed(2)} L</span>
            <span className="dim small">of {(state.water.goalMl / 1000).toFixed(1)} L</span>
          </div>
          <div className="bar"><span style={{ width: `${waterPct}%`, background: 'linear-gradient(90deg,#5ee7ff,#3d8cff)', boxShadow: '0 0 18px rgba(94,231,255,.35)' }} /></div>
          <div className="row mt-2">
            {[250, 500].map((ml) => (
              <button key={ml} className="btn btn-sm" style={{ flex: 1 }} onClick={() => addWater(ml)}><Plus size={14} /> {ml} ml</button>
            ))}
          </div>
        </section>

        <section className="card span-2">
          <div className="card-head">
            <h2>Recent workouts</h2>
            <Link to="/progress" className="small dim row">History <ChevronRight size={14} /></Link>
          </div>
          {recent.length === 0 ? (
            <p className="muted small">No workouts yet — start your first one above!</p>
          ) : (
            <div className="list">
              {recent.map((h) => {
                const plan = getPlan(state, h.planId);
                return (
                  <div key={h.id} className="list-item">
                    <div className="avatar" style={{ color: plan?.color || 'var(--neon)' }}><Dumbbell size={18} /></div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div className="truncate" style={{ fontWeight: 600 }}>{h.planName}</div>
                      <div className="tiny dim">{formatDate(h.date, { weekday: 'short', day: 'numeric', month: 'short' })} · {formatTime(h.date)} · {h.exercisesCompleted}/{h.totalExercises} exercises</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div className="num" style={{ fontWeight: 600 }}>{Math.round(h.durationSec / 60)} min</div>
                      <div className="tiny" style={{ color: '#ff9a66' }}>{h.calories} kcal</div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
