import { useMemo, useState } from 'react';
import {
  ResponsiveContainer, BarChart, Bar as RBar, AreaChart, Area, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Pie, Cell,
} from 'recharts';
import { Dumbbell, Flame, Clock, Zap, Trophy, Medal, Timer, Trash2, CheckCircle2, CircleDashed, History } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageHeader, StatCard, ChartTooltip, Empty } from '../components/ui';
import Modal from '../components/Modal';
import { totals, dailySeries, weeklySeries, monthlySeries, currentStreak, bestStreak, personalRecords } from '../utils/stats';
import { formatDate, formatTime, fromKey, formatLongDate } from '../utils/date';

const RANGES = { '7D': 7, '30D': 30, '90D': 90 };
const RECORD_ICONS = { time: Timer, fire: Flame, trophy: Trophy, streak: Zap, exercise: Medal };

export default function Progress() {
  const { state, deleteHistory, toast } = useApp();
  const { history } = state;
  const [range, setRange] = useState('30D');
  const [toDelete, setToDelete] = useState(null);
  const [showAll, setShowAll] = useState(false);

  const t = totals(history);
  const daily = useMemo(() => dailySeries(history, RANGES[range]), [history, range]);
  const weekly = useMemo(() => weeklySeries(history, 8), [history]);
  const monthly = useMemo(() => monthlySeries(history, 6), [history]);
  const records = useMemo(() => personalRecords(state), [state]);
  const streak = currentStreak(state);
  const best = bestStreak(state);
  const partial = t.workouts - t.completed;
  const completionRate = t.workouts ? Math.round((t.completed / t.workouts) * 100) : 0;
  const pie = [
    { name: 'Fully completed', value: t.completed, color: '#c6ff3d' },
    { name: 'Partially completed', value: partial, color: '#5ee7ff' },
  ];

  // group history by day (newest first)
  const grouped = useMemo(() => {
    const sorted = [...history].sort((a, b) => (a.date < b.date ? 1 : -1));
    const map = new Map();
    for (const h of sorted) {
      if (!map.has(h.dayKey)) map.set(h.dayKey, []);
      map.get(h.dayKey).push(h);
    }
    return [...map.entries()];
  }, [history]);
  const visibleGroups = showAll ? grouped : grouped.slice(0, 10);

  if (!history.length) {
    return (
      <>
        <PageHeader eyebrow="Module 6" title="Progress Analytics" subtitle="Your charts will appear here after your first workout." />
        <div className="card"><Empty icon={History} title="No workouts logged yet" text="Finish a workout from the planner and your stats, streaks and records will show up here." /></div>
      </>
    );
  }

  return (
    <>
      <PageHeader eyebrow="Module 6" title="Progress Analytics" subtitle="Every session you finish is analysed here — trends, streaks and personal records." />

      <div className="grid grid-4 mb-3 stagger">
        <StatCard icon={Dumbbell} label="Total workouts" value={t.workouts} trend={`${completionRate}% fully completed`} />
        <StatCard icon={Clock} label="Time trained" value={Math.round(t.minutes / 60 * 10) / 10} unit="hours" trend={`${t.minutes} minutes`} color="#5ee7ff" />
        <StatCard icon={Flame} label="Calories burned (est.)" value={t.calories.toLocaleString()} unit="kcal" color="#ff7a3d" />
        <StatCard icon={Zap} label="Current streak" value={streak} unit="days" trend={`Best: ${best} days`} color="#ffd23d" />
      </div>

      <div className="grid grid-3 mb-3">
        <section className="card span-2">
          <div className="card-head wrap">
            <div>
              <h2>Daily activity</h2>
              <div className="card-sub">Minutes per day</div>
            </div>
            <div className="tabs">
              {Object.keys(RANGES).map((r) => <button key={r} className={range === r ? 'active' : ''} onClick={() => setRange(r)}>{r}</button>)}
            </div>
          </div>
          <div style={{ height: 260 }}>
            <ResponsiveContainer>
              <AreaChart data={daily} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                <defs>
                  <linearGradient id="areaG" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0" stopColor="#c6ff3d" stopOpacity={0.5} />
                    <stop offset="1" stopColor="#c6ff3d" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="label" tickLine={false} axisLine={false} interval="preserveStartEnd" minTickGap={18} />
                <YAxis tickLine={false} axisLine={false} />
                <Tooltip content={<ChartTooltip units={{ minutes: 'min', calories: 'kcal' }} />} />
                <Area type="monotone" dataKey="minutes" name="minutes" stroke="#c6ff3d" strokeWidth={2.5} fill="url(#areaG)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="card">
          <div className="card-head"><h2>Completion</h2></div>
          <div style={{ height: 180, position: 'relative' }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie data={pie} dataKey="value" innerRadius={58} outerRadius={80} paddingAngle={3} stroke="none" startAngle={90} endAngle={-270}>
                  {pie.map((p) => <Cell key={p.name} fill={p.color} />)}
                </Pie>
                <Tooltip content={<ChartTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', pointerEvents: 'none' }}>
              <div style={{ textAlign: 'center' }}>
                <div className="num" style={{ fontSize: '1.8rem', fontWeight: 700 }}>{completionRate}%</div>
                <div className="tiny dim">completion</div>
              </div>
            </div>
          </div>
          <div className="col mt-2 small">
            <div className="row-between"><span className="row"><CheckCircle2 size={15} color="#c6ff3d" /> Fully completed</span><strong className="num">{t.completed}</strong></div>
            <div className="row-between"><span className="row"><CircleDashed size={15} color="#5ee7ff" /> Partially completed</span><strong className="num">{partial}</strong></div>
          </div>
        </section>
      </div>

      <div className="grid grid-2 mb-3">
        <section className="card">
          <div className="card-head"><div><h2>Weekly workouts</h2><div className="card-sub">Sessions per week — last 8 weeks</div></div></div>
          <div style={{ height: 240 }}>
            <ResponsiveContainer>
              <BarChart data={weekly} margin={{ top: 8, right: 4, left: -24, bottom: 0 }}>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} />
                <YAxis allowDecimals={false} tickLine={false} axisLine={false} />
                <Tooltip content={<ChartTooltip units={{ minutes: 'min' }} />} cursor={{ fill: 'rgba(255,255,255,.04)' }} />
                <RBar dataKey="workouts" name="workouts" radius={[8, 8, 4, 4]} maxBarSize={34}>
                  {weekly.map((w, i) => <Cell key={i} fill={i === weekly.length - 1 ? '#c6ff3d' : 'rgba(198,255,61,.45)'} />)}
                </RBar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="card">
          <div className="card-head"><div><h2>Monthly progress</h2><div className="card-sub">Calories and active days — last 6 months</div></div></div>
          <div style={{ height: 240 }}>
            <ResponsiveContainer>
              <LineChart data={monthly} margin={{ top: 8, right: 8, left: -10, bottom: 0 }}>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="label" tickLine={false} axisLine={false} />
                <YAxis yAxisId="c" tickLine={false} axisLine={false} />
                <YAxis yAxisId="d" orientation="right" hide />
                <Tooltip content={<ChartTooltip units={{ calories: 'kcal', activeDays: 'days' }} />} />
                <Line yAxisId="c" type="monotone" dataKey="calories" name="calories" stroke="#ff7a3d" strokeWidth={2.5} dot={{ r: 4 }} />
                <Line yAxisId="d" type="monotone" dataKey="activeDays" name="active days" stroke="#5ee7ff" strokeWidth={2.5} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>
      </div>

      <div className="grid grid-3">
        <section className="card">
          <div className="card-head"><h2 className="row"><Trophy size={20} className="neon-text" /> Personal records</h2></div>
          <div className="list">
            {records.map((r) => {
              const Icon = RECORD_ICONS[r.kind] || Medal;
              return (
                <div key={r.title} className="list-item">
                  <div className="avatar" style={{ width: 38, height: 38 }}><Icon size={17} /></div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="small truncate">{r.title}</div>
                    {r.date && <div className="tiny dim">{formatDate(fromKey(r.date), { day: 'numeric', month: 'short', year: 'numeric' })}</div>}
                  </div>
                  <strong className="num small" style={{ textAlign: 'right' }}>{r.value}</strong>
                </div>
              );
            })}
          </div>
        </section>

        <section className="card span-2">
          <div className="card-head">
            <div><h2>Workout history</h2><div className="card-sub">Daily log of every session ({history.length} total)</div></div>
          </div>
          <div className="col" style={{ gap: 18 }}>
            {visibleGroups.map(([day, list]) => (
              <div key={day}>
                <div className="tiny dim mb-1" style={{ textTransform: 'uppercase', letterSpacing: '0.08em' }}>{formatLongDate(fromKey(day))}</div>
                <div className="col" style={{ gap: 8 }}>
                  {list.map((h) => (
                    <div key={h.id} className="row" style={{ padding: '10px 12px', borderRadius: 14, background: 'rgba(0,0,0,.25)', border: '1px solid var(--border)' }}>
                      {h.completed ? <CheckCircle2 size={18} color="#c6ff3d" /> : <CircleDashed size={18} color="#5ee7ff" />}
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div className="truncate" style={{ fontWeight: 600 }}>{h.planName}</div>
                        <div className="tiny dim">{formatTime(h.date)} · {h.level || '—'} · {h.exercisesCompleted}/{h.totalExercises} exercises</div>
                      </div>
                      <div className="small num hide-mobile" style={{ width: 70, textAlign: 'right' }}>{Math.round(h.durationSec / 60)} min</div>
                      <div className="small num" style={{ width: 74, textAlign: 'right', color: '#ff9a66' }}>{h.calories} kcal</div>
                      <button className="btn btn-icon sm btn-ghost" aria-label="Delete entry" onClick={() => setToDelete(h)}><Trash2 size={15} /></button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          {grouped.length > 10 && (
            <button className="btn btn-block mt-2" onClick={() => setShowAll((v) => !v)}>{showAll ? 'Show less' : `Show all ${grouped.length} days`}</button>
          )}
        </section>
      </div>

      {toDelete && (
        <Modal size="sm" title="Delete this workout?" onClose={() => setToDelete(null)}>
          <p className="muted">“{toDelete.planName}” on {formatDate(toDelete.date)} will be removed from your history and stats.</p>
          <div className="row mt-3" style={{ justifyContent: 'flex-end' }}>
            <button className="btn" onClick={() => setToDelete(null)}>Cancel</button>
            <button className="btn btn-danger" onClick={() => { deleteHistory(toDelete.id); toast('Workout removed'); setToDelete(null); }}><Trash2 size={16} /> Delete</button>
          </div>
        </Modal>
      )}
    </>
  );
}
