import { useMemo, useState } from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, Cell } from 'recharts';
import { Droplets, Plus, Minus, Trash2, RotateCcw, Target, GlassWater, CupSoda, Milk } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageHeader, ChartTooltip } from '../components/ui';
import Modal from '../components/Modal';
import { todayKey, toKey, addDays, formatTime } from '../utils/date';

const QUICK = [
  { ml: 150, label: 'Small cup', icon: CupSoda },
  { ml: 250, label: 'Glass', icon: GlassWater },
  { ml: 500, label: 'Bottle', icon: Milk },
];

export default function Water() {
  const { state, addWater, removeWater, resetWaterToday, setWaterGoal, toast } = useApp();
  const [custom, setCustom] = useState(300);
  const [goalEdit, setGoalEdit] = useState(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const goal = state.water.goalMl;
  const logs = state.water.logs[todayKey()] || [];
  const total = logs.reduce((a, w) => a + w.ml, 0);
  const pct = Math.min(100, Math.round((total / goal) * 100));

  const week = useMemo(() => {
    const out = [];
    for (let i = 6; i >= 0; i--) {
      const d = addDays(new Date(), -i);
      const ml = (state.water.logs[toKey(d)] || []).reduce((a, w) => a + w.ml, 0);
      out.push({ label: d.toLocaleDateString(undefined, { weekday: 'short' }), litres: Math.round(ml / 100) / 10, hit: ml >= goal });
    }
    return out;
  }, [state.water, goal]);
  const daysHit = week.filter((d) => d.hit).length;

  const add = (ml) => {
    addWater(ml);
    toast(`+${ml} ml added`);
  };

  return (
    <>
      <PageHeader
        eyebrow="Module 8"
        title="Water Tracker"
        subtitle="Stay hydrated — log every glass. The tracker starts fresh automatically each day."
        actions={<button className="btn" onClick={() => setConfirmReset(true)} disabled={!logs.length}><RotateCcw size={16} /> Reset today</button>}
      />

      <div className="grid grid-3 mb-3">
        <section className="card" style={{ textAlign: 'center' }}>
          <div className="bottle" aria-label={`${pct}% of daily water goal`}>
            <div className="bottle-fill" style={{ height: `${pct}%` }} />
            <div className="bottle-label">{pct}%</div>
          </div>
          <div className="num mt-2" style={{ fontSize: '1.8rem', fontWeight: 700 }}>{(total / 1000).toFixed(2)} L</div>
          <div className="small dim">of {(goal / 1000).toFixed(1)} L daily goal · {Math.max(0, goal - total)} ml to go</div>
          {pct >= 100 && <div className="badge neon mt-1">Goal reached! 💧</div>}
        </section>

        <section className="card span-2">
          <h2 className="mb-2">Add water</h2>
          <div className="grid grid-3" style={{ gap: 12 }}>
            {QUICK.map((q) => {
              const Icon = q.icon;
              return (
                <button key={q.ml} className="card hover" style={{ cursor: 'pointer', textAlign: 'center', padding: 18, animation: 'none' }} onClick={() => add(q.ml)}>
                  <Icon size={28} style={{ margin: '0 auto', color: 'var(--cyan)' }} />
                  <div className="num mt-1" style={{ fontWeight: 700, fontSize: '1.2rem' }}>+{q.ml} ml</div>
                  <div className="tiny dim">{q.label}</div>
                </button>
              );
            })}
          </div>
          <div className="row wrap mt-2">
            <div style={{ position: 'relative', flex: '1 1 160px' }}>
              <input type="number" className="input" value={custom} min={10} max={3000} onChange={(e) => setCustom(Number(e.target.value))} aria-label="Custom amount in ml" />
              <span className="input-suffix">ml</span>
            </div>
            <button className="btn btn-primary" disabled={!custom || custom <= 0 || custom > 3000} onClick={() => add(custom)}><Plus size={16} /> Add custom</button>
            <button className="btn" disabled={!logs.length} onClick={() => { removeWater(); toast('Last entry removed'); }}><Minus size={16} /> Undo last</button>
          </div>

          <div className="divider" />
          <div className="row-between mb-1">
            <h3>Today's log</h3>
            <span className="tiny dim">{logs.length} entries</span>
          </div>
          {logs.length === 0 ? (
            <p className="small muted">No water logged yet today.</p>
          ) : (
            <div className="chips">
              {[...logs].reverse().map((w) => (
                <span key={w.id} className="chip" style={{ cursor: 'default', display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                  <Droplets size={13} color="#5ee7ff" /> {w.ml} ml <span className="dim tiny">{formatTime(w.time)}</span>
                  <button aria-label="Remove entry" onClick={() => removeWater(w.id)} style={{ background: 'none', border: 0, color: 'var(--text-3)', cursor: 'pointer', padding: 0, display: 'grid' }}><Trash2 size={13} /></button>
                </span>
              ))}
            </div>
          )}
        </section>
      </div>

      <div className="grid grid-3">
        <section className="card span-2">
          <div className="card-head"><div><h2>Last 7 days</h2><div className="card-sub">Goal reached on {daysHit} of 7 days</div></div></div>
          <div style={{ height: 240 }}>
            <ResponsiveContainer>
              <BarChart data={week} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="label" tickLine={false} axisLine={false} />
                <YAxis tickLine={false} axisLine={false} />
                <Tooltip content={<ChartTooltip units={{ litres: 'L' }} />} cursor={{ fill: 'rgba(255,255,255,.04)' }} />
                <ReferenceLine y={goal / 1000} stroke="#5ee7ff" strokeDasharray="4 4" label={{ value: 'Goal', fill: '#5ee7ff', fontSize: 11, position: 'insideTopRight' }} />
                <Bar dataKey="litres" name="litres" radius={[8, 8, 4, 4]} maxBarSize={36}>
                  {week.map((d, i) => <Cell key={i} fill={d.hit ? '#5ee7ff' : 'rgba(94,231,255,.35)'} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>
        <section className="card">
          <h2 className="row mb-2"><Target size={20} style={{ color: 'var(--cyan)' }} /> Daily goal</h2>
          <div className="num" style={{ fontSize: '2rem', fontWeight: 700 }}>{(goal / 1000).toFixed(1)} L</div>
          <p className="small muted mt-1">A common guideline is about 2–3 litres a day for adults, more when it’s hot or you train hard. Your needs may differ.</p>
          <div className="chips mt-2">
            {[2000, 2500, 3000, 3500].map((g) => (
              <button key={g} className={`chip${goal === g ? ' active' : ''}`} onClick={() => { setWaterGoal(g); toast(`Goal set to ${g / 1000} L`); }}>{g / 1000} L</button>
            ))}
            <button className="chip" onClick={() => setGoalEdit(goal)}>Custom…</button>
          </div>
        </section>
      </div>

      {goalEdit != null && (
        <Modal size="sm" title="Custom water goal" onClose={() => setGoalEdit(null)}>
          <div style={{ position: 'relative' }}>
            <input type="number" className="input" value={goalEdit} min={500} max={8000} step={100} onChange={(e) => setGoalEdit(Number(e.target.value))} autoFocus />
            <span className="input-suffix">ml</span>
          </div>
          <div className="row mt-3" style={{ justifyContent: 'flex-end' }}>
            <button className="btn" onClick={() => setGoalEdit(null)}>Cancel</button>
            <button className="btn btn-primary" disabled={goalEdit < 500 || goalEdit > 8000} onClick={() => { setWaterGoal(goalEdit); toast('Goal updated'); setGoalEdit(null); }}>Save goal</button>
          </div>
        </Modal>
      )}
      {confirmReset && (
        <Modal size="sm" title="Reset today's water?" onClose={() => setConfirmReset(false)}>
          <p className="muted">All {logs.length} entries for today will be removed. Previous days are kept.</p>
          <div className="row mt-3" style={{ justifyContent: 'flex-end' }}>
            <button className="btn" onClick={() => setConfirmReset(false)}>Cancel</button>
            <button className="btn btn-danger" onClick={() => { resetWaterToday(); toast('Today reset'); setConfirmReset(false); }}><RotateCcw size={16} /> Reset</button>
          </div>
        </Modal>
      )}
    </>
  );
}
