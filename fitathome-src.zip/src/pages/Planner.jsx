import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Plus, Play, Clock, Flame, Dumbbell, Pencil, Trash2, Copy, CalendarCheck, CalendarPlus } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageHeader, Empty } from '../components/ui';
import Modal from '../components/Modal';
import { getAllPlans } from '../utils/stats';
import { LEVELS, WEEKDAY_SHORT } from '../data/plans';
import { scaleItems, estimateDuration, estimateCalories } from '../utils/workout';
import { humanDuration } from '../utils/date';

const GOAL_FILTERS = ['All', 'Weight Loss', 'Muscle Building', 'Full Body', 'Abs', 'Beginner', 'Strength', 'Flexibility'];

export function DayPills({ days = [], onToggle, small }) {
  return (
    <div className="row" style={{ gap: small ? 4 : 6, flexWrap: 'wrap' }}>
      {WEEKDAY_SHORT.map((d, i) => {
        const on = days.includes(i);
        const style = {
          width: small ? 30 : 42,
          height: small ? 24 : 34,
          borderRadius: 9,
          fontSize: small ? '0.68rem' : '0.8rem',
          fontWeight: 600,
          display: 'grid',
          placeItems: 'center',
          border: `1px solid ${on ? 'var(--neon)' : 'var(--border)'}`,
          background: on ? 'var(--neon-dim)' : 'transparent',
          color: on ? 'var(--neon)' : 'var(--text-3)',
          cursor: onToggle ? 'pointer' : 'default',
          padding: 0,
        };
        return onToggle ? (
          <button type="button" key={d} style={style} onClick={() => onToggle(i)} aria-pressed={on}>{small ? d[0] : d}</button>
        ) : (
          <span key={d} style={style}>{small ? d[0] : d}</span>
        );
      })}
    </div>
  );
}

export default function Planner() {
  const { state, deletePlan, toggleSchedule, toast } = useApp();
  const navigate = useNavigate();
  const [tab, setTab] = useState('all');
  const [goal, setGoal] = useState('All');
  const [level, setLevel] = useState(state.profile.level || 'Intermediate');
  const [toDelete, setToDelete] = useState(null);

  const plans = getAllPlans(state).filter((p) => {
    if (tab === 'builtin' && !p.builtIn) return false;
    if (tab === 'custom' && p.builtIn) return false;
    if (goal !== 'All' && p.goal !== goal) return false;
    return true;
  });

  return (
    <>
      <PageHeader
        eyebrow="Module 2"
        title="Workout Planner"
        subtitle="Pick a ready-made program, adjust it to your level, or build your own."
        actions={<Link to="/builder" className="btn btn-primary"><Plus size={16} /> Create custom plan</Link>}
      />

      <div className="card mb-3" style={{ padding: 14 }}>
        <div className="row-between wrap" style={{ gap: 12 }}>
          <div className="tabs" role="tablist">
            {[['all', 'All plans'], ['builtin', 'Predefined'], ['custom', `My plans (${state.customPlans.length})`]].map(([k, l]) => (
              <button key={k} className={tab === k ? 'active' : ''} onClick={() => setTab(k)}>{l}</button>
            ))}
          </div>
          <div className="row small">
            <span className="dim hide-mobile">Fitness level:</span>
            <div className="tabs">
              {LEVELS.map((l) => (
                <button key={l} className={level === l ? 'active' : ''} onClick={() => setLevel(l)}>{l}</button>
              ))}
            </div>
          </div>
        </div>
        <div className="chips scroll mt-2">
          {GOAL_FILTERS.map((g) => (
            <button key={g} className={`chip${goal === g ? ' active' : ''}`} onClick={() => setGoal(g)}>{g}</button>
          ))}
        </div>
      </div>

      {plans.length === 0 ? (
        <div className="card">
          <Empty icon={Dumbbell} title="No plans here yet" text="Create your own plan with the workout builder." action={<Link to="/builder" className="btn btn-primary"><Plus size={16} /> Build a plan</Link>} />
        </div>
      ) : (
        <div className="grid grid-auto stagger" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))' }}>
          {plans.map((p) => {
            const items = p.builtIn ? scaleItems(p.items, level, p.level) : p.items;
            const scheduled = state.scheduledPlanIds.includes(p.id);
            return (
              <article key={p.id} className="card hover" style={{ display: 'flex', flexDirection: 'column', gap: 12, borderTop: `3px solid ${p.color}` }}>
                <div className="row-between">
                  <span className="badge" style={{ color: p.color, background: `${p.color}1f` }}>{p.goal}</span>
                  <span className={`badge ${p.builtIn ? level : p.level}`}>{p.builtIn ? level : p.level}{!p.builtIn && ' · Custom'}</span>
                </div>
                <Link to={`/plans/${p.id}`}><h2>{p.name}</h2></Link>
                <p className="small muted" style={{ minHeight: 40 }}>{p.description || 'Custom workout plan.'}</p>
                <div className="row small dim wrap">
                  <span className="row" style={{ gap: 4 }}><Dumbbell size={14} /> {items.length} exercises</span>
                  <span className="row" style={{ gap: 4 }}><Clock size={14} /> {humanDuration(estimateDuration(items))}</span>
                  <span className="row" style={{ gap: 4 }}><Flame size={14} /> ~{estimateCalories(items, state.profile.weightKg)} kcal</span>
                </div>
                <DayPills days={p.days} small />
                <div className="row mt-1" style={{ marginTop: 'auto' }}>
                  <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={() => navigate(`/workout/${p.id}${p.builtIn ? `?level=${level}` : ''}`)}>
                    <Play size={14} /> Start
                  </button>
                  <button
                    className={`btn btn-sm btn-icon${scheduled ? '' : ' btn-ghost'}`}
                    title={scheduled ? 'Remove from my schedule' : 'Add to my schedule'}
                    style={scheduled ? { color: 'var(--neon)', borderColor: 'rgba(198,255,61,.4)' } : undefined}
                    onClick={() => { toggleSchedule(p.id); toast(scheduled ? `${p.name} removed from schedule` : `${p.name} added to schedule`); }}
                  >
                    {scheduled ? <CalendarCheck size={16} /> : <CalendarPlus size={16} />}
                  </button>
                  {p.builtIn ? (
                    <button className="btn btn-sm btn-icon" title="Copy & customise" onClick={() => navigate(`/builder?from=${p.id}&level=${level}`)}><Copy size={16} /></button>
                  ) : (
                    <>
                      <button className="btn btn-sm btn-icon" title="Edit plan" onClick={() => navigate(`/builder/${p.id}`)}><Pencil size={16} /></button>
                      <button className="btn btn-sm btn-icon btn-danger" title="Delete plan" onClick={() => setToDelete(p)}><Trash2 size={16} /></button>
                    </>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}

      {toDelete && (
        <Modal title="Delete plan?" size="sm" onClose={() => setToDelete(null)}>
          <p className="muted">“{toDelete.name}” will be permanently removed. Your past workout history is kept.</p>
          <div className="row mt-3" style={{ justifyContent: 'flex-end' }}>
            <button className="btn" onClick={() => setToDelete(null)}>Cancel</button>
            <button className="btn btn-danger" onClick={() => { deletePlan(toDelete.id); toast('Plan deleted'); setToDelete(null); }}><Trash2 size={16} /> Delete</button>
          </div>
        </Modal>
      )}
    </>
  );
}
