import { useMemo, useState } from 'react';
import { useNavigate, useParams, useSearchParams, useLocation } from 'react-router-dom';
import { Plus, Save, Trash2, ArrowUp, ArrowDown, Search, Clock, Flame, Dumbbell, X, Hammer, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageHeader, Stepper, Empty } from '../components/ui';
import Modal from '../components/Modal';
import ExerciseFigure from '../components/ExerciseFigure';
import { DayPills } from './Planner';
import { EXERCISES, EXERCISE_MAP, CATEGORIES } from '../data/exercises';
import { GOALS, LEVELS } from '../data/plans';
import { getPlan } from '../utils/stats';
import { scaleItems, estimateDuration, estimateCalories } from '../utils/workout';
import { humanDuration } from '../utils/date';

const COLORS = ['#c6ff3d', '#3dff8b', '#5ee7ff', '#ffd23d', '#ff7a3d', '#ff5ea8', '#b08cff'];

const itemFromExercise = (ex) =>
  ex.type === 'time'
    ? { exerciseId: ex.id, sets: ex.sets, duration: ex.duration, rest: ex.rest }
    : { exerciseId: ex.id, sets: ex.sets, reps: ex.reps, rest: ex.rest };

function initialDraft(state, id, params) {
  if (id) {
    const existing = state.customPlans.find((p) => p.id === id);
    if (existing) return { ...existing, items: existing.items.map((i) => ({ ...i })) };
  }
  const from = params.get('from');
  if (from) {
    const src = getPlan(state, from);
    if (src) {
      const level = params.get('level') || src.level;
      return {
        name: `${src.name} (My version)`,
        description: src.description,
        goal: src.goal,
        level: src.builtIn ? level : src.level,
        color: src.color,
        days: [...src.days],
        items: src.builtIn ? scaleItems(src.items, level, src.level) : src.items.map((i) => ({ ...i })),
      };
    }
  }
  const add = params.get('add');
  return {
    name: '',
    description: '',
    goal: state.profile.goal || 'General Fitness',
    level: state.profile.level || 'Beginner',
    color: COLORS[state.customPlans.length % COLORS.length],
    days: [],
    items: add && EXERCISE_MAP[add] ? [itemFromExercise(EXERCISE_MAP[add])] : [],
  };
}

/** Re-mount the builder whenever the URL changes (new plan / edit / copy). */
export default function Builder() {
  const location = useLocation();
  return <BuilderForm key={location.key} />;
}

function BuilderForm() {
  const { id } = useParams();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const { state, savePlan, toast } = useApp();
  const [draft, setDraft] = useState(() => initialDraft(state, id, params));
  const [picker, setPicker] = useState(false);
  const [errors, setErrors] = useState({});
  const editing = !!(id && state.customPlans.some((p) => p.id === id));

  const set = (patch) => setDraft((d) => ({ ...d, ...patch }));
  const setItem = (idx, patch) => setDraft((d) => ({ ...d, items: d.items.map((it, i) => (i === idx ? { ...it, ...patch } : it)) }));
  const removeItem = (idx) => setDraft((d) => ({ ...d, items: d.items.filter((_, i) => i !== idx) }));
  const move = (idx, dir) =>
    setDraft((d) => {
      const items = [...d.items];
      const j = idx + dir;
      if (j < 0 || j >= items.length) return d;
      [items[idx], items[j]] = [items[j], items[idx]];
      return { ...d, items };
    });
  const toggleDay = (day) => set({ days: draft.days.includes(day) ? draft.days.filter((x) => x !== day) : [...draft.days, day].sort() });
  const addExercises = (ids) => {
    setDraft((d) => ({ ...d, items: [...d.items, ...ids.map((x) => itemFromExercise(EXERCISE_MAP[x]))] }));
    setPicker(false);
  };

  const save = () => {
    const e = {};
    if (!draft.name.trim()) e.name = 'Give your workout a name.';
    if (!draft.items.length) e.items = 'Add at least one exercise.';
    setErrors(e);
    if (Object.keys(e).length) {
      toast(Object.values(e)[0], 'error');
      return;
    }
    const newId = savePlan({ ...draft, name: draft.name.trim(), id: editing ? id : undefined });
    toast(editing ? 'Workout plan updated' : 'Workout plan saved');
    navigate(`/plans/${newId}`);
  };

  const duration = estimateDuration(draft.items);
  const kcal = estimateCalories(draft.items, state.profile.weightKg);

  return (
    <>
      <PageHeader
        eyebrow="Module 5"
        title={editing ? 'Edit workout' : 'Custom workout builder'}
        subtitle="Choose exercises, set your sets, reps and rest, pick your days — then save."
        actions={
          <>
            <button className="btn" onClick={() => navigate(-1)}>Cancel</button>
            <button className="btn btn-primary" onClick={save}><Save size={16} /> {editing ? 'Save changes' : 'Save plan'}</button>
          </>
        }
      />

      <div className="grid grid-3">
        <section className="card span-2">
          <div className="form-grid">
            <div className="field" style={{ gridColumn: '1 / -1' }}>
              <label className="label" htmlFor="pname">Workout name *</label>
              <input id="pname" className="input" placeholder="e.g. Morning Power 20" value={draft.name} onChange={(e) => set({ name: e.target.value })} style={errors.name ? { borderColor: 'var(--red)' } : undefined} />
            </div>
            <div className="field" style={{ gridColumn: '1 / -1' }}>
              <label className="label" htmlFor="pdesc">Description</label>
              <input id="pdesc" className="input" placeholder="What is this workout for?" value={draft.description} onChange={(e) => set({ description: e.target.value })} />
            </div>
            <div className="field">
              <label className="label" htmlFor="pgoal">Goal</label>
              <select id="pgoal" className="select" value={draft.goal} onChange={(e) => set({ goal: e.target.value })}>
                {GOALS.map((g) => <option key={g}>{g}</option>)}
              </select>
            </div>
            <div className="field">
              <label className="label" htmlFor="plevel">Level</label>
              <select id="plevel" className="select" value={draft.level} onChange={(e) => set({ level: e.target.value })}>
                {LEVELS.map((g) => <option key={g}>{g}</option>)}
              </select>
            </div>
            <div className="field">
              <span className="label">Workout days</span>
              <DayPills days={draft.days} onToggle={toggleDay} />
            </div>
            <div className="field">
              <span className="label">Colour tag</span>
              <div className="row">
                {COLORS.map((c) => (
                  <button key={c} type="button" aria-label={`Colour ${c}`} onClick={() => set({ color: c })} style={{ width: 28, height: 28, borderRadius: 9, background: c, border: draft.color === c ? '2px solid #fff' : '2px solid transparent', cursor: 'pointer', display: 'grid', placeItems: 'center', color: '#000' }}>
                    {draft.color === c && <Check size={14} />}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="divider" />
          <div className="row-between mb-2">
            <h2>Exercises <span className="dim small">({draft.items.length})</span></h2>
            <button className="btn btn-primary btn-sm" onClick={() => setPicker(true)}><Plus size={15} /> Add exercises</button>
          </div>
          {errors.items && !draft.items.length && <p className="small" style={{ color: 'var(--red)' }}>{errors.items}</p>}
          {draft.items.length === 0 ? (
            <Empty icon={Hammer} title="No exercises yet" text="Add exercises from the library of 60+ moves." action={<button className="btn" onClick={() => setPicker(true)}><Plus size={16} /> Browse exercises</button>} />
          ) : (
            <div className="col" style={{ gap: 10 }}>
              {draft.items.map((it, idx) => {
                const ex = EXERCISE_MAP[it.exerciseId];
                const timed = it.duration != null;
                return (
                  <div key={`${it.exerciseId}-${idx}`} className="card" style={{ padding: 12, background: 'rgba(0,0,0,.25)', animation: 'none' }}>
                    <div className="row" style={{ alignItems: 'flex-start' }}>
                      <div className="figure-box" style={{ width: 64, flex: 'none', borderRadius: 12 }}><ExerciseFigure pose={ex.pose} animate={false} /></div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div className="row-between">
                          <strong className="truncate">{idx + 1}. {ex.name}</strong>
                          <div className="row" style={{ gap: 4 }}>
                            <button className="btn btn-icon sm btn-ghost" onClick={() => move(idx, -1)} disabled={idx === 0} aria-label="Move up"><ArrowUp size={15} /></button>
                            <button className="btn btn-icon sm btn-ghost" onClick={() => move(idx, 1)} disabled={idx === draft.items.length - 1} aria-label="Move down"><ArrowDown size={15} /></button>
                            <button className="btn btn-icon sm btn-danger" onClick={() => removeItem(idx)} aria-label={`Remove ${ex.name}`}><Trash2 size={15} /></button>
                          </div>
                        </div>
                        <div className="tiny dim mb-1">{ex.muscle}</div>
                        <div className="row wrap" style={{ gap: 14 }}>
                          <label className="col tiny dim" style={{ gap: 4 }}>Sets<Stepper label="sets" value={it.sets} min={1} max={10} onChange={(v) => setItem(idx, { sets: v })} /></label>
                          {timed ? (
                            <label className="col tiny dim" style={{ gap: 4 }}>Seconds<Stepper label="seconds" value={it.duration} min={5} max={600} step={5} onChange={(v) => setItem(idx, { duration: v })} /></label>
                          ) : (
                            <label className="col tiny dim" style={{ gap: 4 }}>Reps<Stepper label="reps" value={it.reps} min={1} max={200} onChange={(v) => setItem(idx, { reps: v })} /></label>
                          )}
                          <label className="col tiny dim" style={{ gap: 4 }}>Rest (s)<Stepper label="rest seconds" value={it.rest} min={0} max={300} step={5} onChange={(v) => setItem(idx, { rest: v })} /></label>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        <aside className="card" style={{ alignSelf: 'start', position: 'sticky', top: 20 }}>
          <h2 className="mb-2">Summary</h2>
          <div className="col">
            <div className="row-between"><span className="row muted"><Dumbbell size={16} /> Exercises</span><strong className="num">{draft.items.length}</strong></div>
            <div className="row-between"><span className="row muted"><Plus size={16} /> Total sets</span><strong className="num">{draft.items.reduce((a, i) => a + i.sets, 0)}</strong></div>
            <div className="row-between"><span className="row muted"><Clock size={16} /> Est. duration</span><strong className="num">{humanDuration(duration)}</strong></div>
            <div className="row-between"><span className="row muted"><Flame size={16} /> Est. calories</span><strong className="num">~{kcal} kcal</strong></div>
          </div>
          <div className="divider" />
          <div className="small dim">Days: {draft.days.length ? draft.days.map((d) => ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d]).join(', ') : 'none (on-demand plan)'}</div>
          <button className="btn btn-primary btn-block mt-2" onClick={save}><Save size={16} /> {editing ? 'Save changes' : 'Save plan'}</button>
        </aside>
      </div>

      {picker && <ExercisePicker onClose={() => setPicker(false)} onAdd={addExercises} />}
    </>
  );
}

function ExercisePicker({ onClose, onAdd }) {
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('All');
  const [selected, setSelected] = useState([]);
  const list = useMemo(
    () => EXERCISES.filter((e) => (cat === 'All' || e.category === cat) && (`${e.name} ${e.muscle}`.toLowerCase().includes(q.toLowerCase()))),
    [q, cat]
  );
  const toggle = (id) => setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  return (
    <Modal title="Add exercises" onClose={onClose}>
      <div className="input-group mb-2">
        <Search size={17} />
        <input className="input" autoFocus placeholder="Search by name or muscle…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="chips scroll mb-2">
        {['All', ...CATEGORIES].map((c) => <button key={c} className={`chip${cat === c ? ' active' : ''}`} onClick={() => setCat(c)}>{c}</button>)}
      </div>
      <div className="col" style={{ gap: 6, maxHeight: '48vh', overflowY: 'auto' }}>
        {list.map((e) => {
          const on = selected.includes(e.id);
          return (
            <button key={e.id} onClick={() => toggle(e.id)} className="row" style={{ padding: 8, borderRadius: 12, border: `1px solid ${on ? 'var(--neon)' : 'var(--border)'}`, background: on ? 'var(--neon-dim)' : 'transparent', cursor: 'pointer', textAlign: 'left' }}>
              <div className="figure-box" style={{ width: 52, flex: 'none', borderRadius: 10 }}><ExerciseFigure pose={e.pose} animate={false} /></div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 600 }}>{e.name}</div>
                <div className="tiny dim truncate">{e.category} · {e.muscle}</div>
              </div>
              <span className={`badge ${e.difficulty}`}>{e.difficulty}</span>
              <span style={{ width: 24, height: 24, borderRadius: 8, border: `1.5px solid ${on ? 'var(--neon)' : 'var(--border-strong)'}`, background: on ? 'var(--neon)' : 'transparent', display: 'grid', placeItems: 'center', color: '#000', flex: 'none' }}>{on && <Check size={14} />}</span>
            </button>
          );
        })}
        {!list.length && <p className="muted small">No exercises match “{q}”.</p>}
      </div>
      <div className="row-between mt-2">
        <button className="btn btn-ghost btn-sm" onClick={() => setSelected([])} disabled={!selected.length}><X size={14} /> Clear</button>
        <button className="btn btn-primary" disabled={!selected.length} onClick={() => onAdd(selected)}><Plus size={16} /> Add {selected.length || ''} exercise{selected.length === 1 ? '' : 's'}</button>
      </div>
    </Modal>
  );
}
