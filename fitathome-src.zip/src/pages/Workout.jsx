import { useCallback, useEffect, useMemo, useReducer, useRef, useState } from 'react';
import { useNavigate, useParams, useSearchParams, Link } from 'react-router-dom';
import {
  X, Play, Pause, RotateCcw, SkipBack, SkipForward, Check, CheckCheck, Plus, Volume2, VolumeX, Mic, MicOff,
  Trophy, Flame, Clock, Dumbbell, BarChart3, Home, Bell, Flag,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import ExerciseFigure from '../components/ExerciseFigure';
import Modal from '../components/Modal';
import { Toasts } from '../components/Layout';
import { ProgressRing } from '../components/ui';
import { getPlan } from '../utils/stats';
import { EXERCISE_MAP } from '../data/exercises';
import { scaleItems, buildSteps, caloriesForWork, REST_MET } from '../utils/workout';
import { clock, humanDuration } from '../utils/date';
import { sounds, speak, unlockAudio, notify, vibrate } from '../utils/audio';

/* ---------- plan resolution (plans, or a single exercise from the library) ---------- */
function resolvePlan(state, planId, level) {
  if (planId?.startsWith('ex-')) {
    const ex = EXERCISE_MAP[planId.slice(3)];
    if (!ex) return null;
    const item = ex.type === 'time'
      ? { exerciseId: ex.id, sets: ex.sets, duration: ex.duration, rest: ex.rest }
      : { exerciseId: ex.id, sets: ex.sets, reps: ex.reps, rest: ex.rest };
    return { id: planId, name: ex.name, color: '#c6ff3d', level: ex.difficulty, items: [item], single: true };
  }
  const plan = getPlan(state, planId);
  if (!plan) return null;
  const lvl = plan.builtIn ? level || state.profile.level || plan.level : plan.level;
  return { ...plan, level: lvl, items: plan.builtIn ? scaleItems(plan.items, lvl, plan.level) : plan.items };
}

/* ---------- timer state machine ---------- */
const init = (steps) => ({
  status: 'idle', // idle | running | paused | finished
  index: 0,
  remaining: steps[0].seconds,
  phaseEnd: 0,
  done: [], // indices of completed work steps
  activeMs: 0,
  lastResume: 0,
  startedAt: null,
});

function reducer(s, a) {
  switch (a.type) {
    case 'start':
    case 'resume':
      return { ...s, status: 'running', phaseEnd: a.now + s.remaining * 1000, lastResume: a.now, startedAt: s.startedAt || a.now };
    case 'pause':
      return { ...s, status: 'paused', remaining: Math.max(0, (s.phaseEnd - a.now) / 1000), activeMs: s.activeMs + (a.now - s.lastResume) };
    case 'tick':
      return { ...s, remaining: Math.max(0, (s.phaseEnd - a.now) / 1000) };
    case 'goto':
      return {
        ...s,
        index: a.index,
        done: a.done ?? s.done,
        remaining: a.seconds,
        phaseEnd: s.status === 'running' ? a.now + a.seconds * 1000 : s.phaseEnd,
      };
    case 'addTime':
      return { ...s, remaining: s.remaining + a.seconds, phaseEnd: s.phaseEnd + a.seconds * 1000 };
    case 'finish':
      return {
        ...s,
        status: 'finished',
        done: a.done ?? s.done,
        activeMs: s.status === 'running' ? s.activeMs + (a.now - s.lastResume) : s.activeMs,
      };
    case 'reset':
      return a.initial;
    default:
      return s;
  }
}

export default function Workout() {
  const { planId } = useParams();
  const [params] = useSearchParams();
  const { state } = useApp();
  const plan = useMemo(() => resolvePlan(state, planId, params.get('level')), [planId]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!plan || !plan.items.length) {
    return (
      <div className="main" style={{ marginLeft: 0, maxWidth: 600, margin: '10vh auto' }}>
        <div className="card" style={{ textAlign: 'center' }}>
          <h2>Workout not found</h2>
          <p className="muted mt-1">This plan doesn't exist or has no exercises.</p>
          <Link to="/planner" className="btn btn-primary mt-2">Go to planner</Link>
        </div>
      </div>
    );
  }
  return <Player plan={plan} />;
}

function Player({ plan }) {
  const navigate = useNavigate();
  const { state, addHistory, updatePreferences } = useApp();
  const prefs = state.preferences;
  const weight = Number(state.profile.weightKg) || 70;

  const steps = useMemo(
    () => [{ kind: 'prepare', seconds: Math.max(3, prefs.countdown || 5), exIndex: 0, exerciseId: plan.items[0].exerciseId }, ...buildSteps(plan.items)],
    [plan] // eslint-disable-line react-hooks/exhaustive-deps
  );
  const initial = useMemo(() => init(steps), [steps]);
  const [s, dispatch] = useReducer(reducer, initial);
  const sRef = useRef(s);
  sRef.current = s;
  const prefsRef = useRef(prefs);
  prefsRef.current = prefs;
  const lastBeep = useRef(null);
  const handled = useRef(null);
  const announced = useRef(null);
  const saved = useRef(null);
  const [confirm, setConfirm] = useState(null); // 'reset' | 'end' | 'leave'
  const [now, setNow] = useState(Date.now());
  const [compact, setCompact] = useState(() => window.matchMedia('(max-width: 600px)').matches);
  useEffect(() => {
    const mq = window.matchMedia('(max-width: 600px)');
    const h = (e) => setCompact(e.matches);
    mq.addEventListener?.('change', h);
    return () => mq.removeEventListener?.('change', h);
  }, []);

  const step = steps[s.index];
  const ex = EXERCISE_MAP[step.exerciseId];
  const item = plan.items[step.exIndex];
  const workIdx = useMemo(() => steps.map((st, i) => (st.kind === 'work' ? i : -1)).filter((i) => i >= 0), [steps]);
  const totalWork = workIdx.length;

  const cue = useCallback((kind, text) => {
    const p = prefsRef.current;
    if (p.sound) sounds[kind]?.();
    if (p.voice && text) speak(text);
    if (p.vibrate && kind !== 'tick') vibrate(kind === 'finish' ? [100, 60, 100, 60, 200] : 120);
  }, []);

  /* ---- navigation helpers ---- */
  const finish = useCallback((done) => {
    dispatch({ type: 'finish', now: Date.now(), done });
    cue('finish', 'Workout complete. Great job!');
    if (document.hidden) notify('Workout complete! 🎉', `${plan.name} finished. Great job!`);
  }, [cue, plan.name]);

  const goto = useCallback((index, done) => {
    if (index >= steps.length) return finish(done ?? sRef.current.done);
    dispatch({ type: 'goto', index, seconds: steps[index].seconds, now: Date.now(), done });
  }, [steps, finish]);

  const completeCurrent = useCallback(() => {
    const cur = sRef.current;
    const st = steps[cur.index];
    const done = st.kind === 'work' && !cur.done.includes(cur.index) ? [...cur.done, cur.index] : cur.done;
    goto(cur.index + 1, done);
  }, [steps, goto]);

  const nextExercise = useCallback(() => {
    const cur = sRef.current;
    const curEx = steps[cur.index].kind === 'prepare' ? -1 : steps[cur.index].exIndex;
    const target = workIdx.find((i) => steps[i].exIndex > curEx);
    if (target == null) return finish(cur.done);
    goto(target);
  }, [steps, workIdx, goto, finish]);

  const prevExercise = useCallback(() => {
    const cur = sRef.current;
    const st = steps[cur.index];
    if (st.kind === 'prepare') return;
    const firstOfCurrent = workIdx.find((i) => steps[i].exIndex === st.exIndex);
    if (cur.index > firstOfCurrent && (st.kind === 'rest' || st.set > 1)) return goto(firstOfCurrent);
    const prevEx = st.exIndex - 1;
    if (prevEx < 0) return goto(firstOfCurrent);
    goto(workIdx.find((i) => steps[i].exIndex === prevEx));
  }, [steps, workIdx, goto]);

  const completeExercise = useCallback(() => {
    const cur = sRef.current;
    const st = steps[cur.index];
    if (st.kind === 'prepare') return;
    const mine = workIdx.filter((i) => steps[i].exIndex === st.exIndex);
    const done = Array.from(new Set([...cur.done, ...mine]));
    const target = workIdx.find((i) => steps[i].exIndex > st.exIndex);
    if (target == null) return finish(done);
    goto(target, done);
  }, [steps, workIdx, goto, finish]);

  const start = () => {
    unlockAudio();
    if (s.status === 'idle') dispatch({ type: 'start', now: Date.now() });
    else dispatch({ type: 'resume', now: Date.now() });
  };
  const pause = () => dispatch({ type: 'pause', now: Date.now() });
  const reset = () => {
    window.speechSynthesis?.cancel();
    handled.current = null;
    announced.current = null;
    lastBeep.current = null;
    saved.current = null;
    dispatch({ type: 'reset', initial });
  };

  /* ---- the ticking clock (timestamp-based, so it never drifts) ---- */
  useEffect(() => {
    if (s.status !== 'running') return undefined;
    const id = setInterval(() => {
      const t = Date.now();
      setNow(t);
      const cur = sRef.current;
      if (cur.status !== 'running') return;
      const remaining = (cur.phaseEnd - t) / 1000;
      const whole = Math.ceil(remaining);
      const key = `${cur.index}:${cur.phaseEnd}`;
      if (whole <= 3 && whole >= 1 && lastBeep.current !== `${key}:${whole}`) {
        lastBeep.current = `${key}:${whole}`;
        if (prefsRef.current.sound) sounds.tick();
      }
      if (remaining <= 0) {
        if (handled.current === key) return;
        const st = steps[cur.index];
        // rep-based sets wait for the user when auto-advance is off
        if (st.kind === 'work' && st.mode === 'reps' && !prefsRef.current.autoAdvance) {
          dispatch({ type: 'tick', now: t });
          return;
        }
        handled.current = key;
        completeCurrent();
      } else {
        dispatch({ type: 'tick', now: t });
      }
    }, 200);
    return () => clearInterval(id);
  }, [s.status, steps, completeCurrent]);

  /* ---- voice / sound announcements when a new step begins ---- */
  useEffect(() => {
    if (s.status !== 'running') return;
    const key = `${s.index}:${s.phaseEnd}`;
    if (announced.current === key) return;
    announced.current = key;
    const st = steps[s.index];
    const e = EXERCISE_MAP[st.exerciseId];
    if (st.kind === 'prepare') cue('click', `Get ready. First up: ${e.name}`);
    else if (st.kind === 'work') {
      const target = st.mode === 'time' ? `${st.seconds} seconds` : `${st.reps} reps`;
      cue('go', `${e.name}. Set ${st.set} of ${st.totalSets}. ${target}`);
    } else {
      const next = steps[s.index + 1];
      const nextName = next ? EXERCISE_MAP[next.exerciseId].name : '';
      cue('rest', `Rest ${st.seconds} seconds.${next && next.exerciseId !== st.exerciseId ? ` Next: ${nextName}` : ''}`);
    }
  }, [s.index, s.status, s.phaseEnd, steps, cue]);

  /* ---- keep the screen awake while training (where supported) ---- */
  useEffect(() => {
    if (s.status !== 'running' || !('wakeLock' in navigator)) return undefined;
    let lock;
    navigator.wakeLock.request('screen').then((l) => { lock = l; }).catch(() => {});
    return () => { lock?.release?.().catch(() => {}); };
  }, [s.status]);

  /* ---- warn before closing the tab mid-workout ---- */
  useEffect(() => {
    if (s.status !== 'running' && s.status !== 'paused') return undefined;
    const h = (e) => { e.preventDefault(); e.returnValue = ''; };
    window.addEventListener('beforeunload', h);
    return () => window.removeEventListener('beforeunload', h);
  }, [s.status]);

  /* ---- keyboard shortcuts ---- */
  useEffect(() => {
    const onKey = (e) => {
      if (confirm || s.status === 'finished' || ['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;
      if (e.code === 'Space') { e.preventDefault(); s.status === 'running' ? pause() : start(); }
      if (e.code === 'ArrowRight') nextExercise();
      if (e.code === 'ArrowLeft') prevExercise();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  useEffect(() => () => window.speechSynthesis?.cancel(), []);

  /* ---- results ---- */
  const results = useMemo(() => {
    const activeSec = Math.round((s.activeMs + (s.status === 'running' ? now - s.lastResume : 0)) / 1000);
    let workSec = 0;
    let kcal = 0;
    for (const i of s.done) {
      const st = steps[i];
      const sec = st.mode === 'time' ? st.seconds : (st.reps || 0) * 3;
      workSec += sec;
      kcal += caloriesForWork(st.exerciseId, sec, weight);
    }
    kcal += REST_MET * weight * (Math.max(0, activeSec - workSec) / 3600);
    const perExercise = plan.items.map((it, idx) => {
      const setsDone = s.done.filter((i) => steps[i].exIndex === idx).length;
      return {
        exerciseId: it.exerciseId,
        name: EXERCISE_MAP[it.exerciseId]?.name,
        totalSets: it.sets,
        setsDone,
        reps: it.reps ?? null,
        duration: it.duration ?? null,
      };
    });
    return { activeSec, kcal: Math.round(kcal), perExercise };
  }, [s.done, s.activeMs, s.status, s.lastResume, now, steps, plan.items, weight]);

  // Save once when finished (only if at least one set was completed)
  useEffect(() => {
    if (s.status !== 'finished' || saved.current) return;
    if (!s.done.length) { saved.current = 'none'; return; }
    const exercisesCompleted = results.perExercise.filter((e) => e.setsDone >= e.totalSets).length;
    saved.current = addHistory({
      planId: plan.id,
      planName: plan.name,
      level: plan.level,
      durationSec: Math.max(results.activeSec, 1),
      calories: results.kcal,
      totalExercises: plan.items.length,
      exercisesCompleted,
      completed: s.done.length === totalWork,
      exercises: results.perExercise,
    });
  }, [s.status]); // eslint-disable-line react-hooks/exhaustive-deps

  if (s.status === 'finished') {
    return <Summary plan={plan} results={results} setsDone={s.done.length} totalWork={totalWork} saved={saved.current} onAgain={reset} />;
  }

  /* ---- render ---- */
  const progress = (s.done.length / totalWork) * 100;
  const phaseTotal = step.seconds;
  const phasePct = ((phaseTotal - s.remaining) / phaseTotal) * 100;
  const isWork = step.kind === 'work';
  const isRest = step.kind === 'rest';
  const nextStep = steps.slice(s.index + 1).find((x) => x.kind === 'work');
  const nextEx = nextStep && EXERCISE_MAP[nextStep.exerciseId];
  const elapsed = Math.round((s.activeMs + (s.status === 'running' ? now - s.lastResume : 0)) / 1000);
  const ringColor = isRest ? '#5ee7ff' : step.kind === 'prepare' ? '#ffd23d' : 'var(--neon)';
  const showFigureEx = isRest && nextEx ? nextEx : ex;

  return (
    <div style={{ minHeight: '100vh', padding: '16px clamp(12px, 3vw, 32px) 32px', maxWidth: 1280, margin: '0 auto' }}>
      {/* Top bar */}
      <div className="row-between mb-2 wrap" style={{ gap: 12 }}>
        <div className="row" style={{ minWidth: 0 }}>
          <button className="btn btn-icon" aria-label="Exit workout" onClick={() => (s.status === 'idle' ? navigate(-1) : setConfirm('leave'))}><X size={18} /></button>
          <div style={{ minWidth: 0 }}>
            <div className="eyebrow" style={{ marginBottom: 2 }}>Live workout · {plan.level}</div>
            <h2 className="truncate">{plan.name}</h2>
          </div>
        </div>
        <div className="row">
          <span className="badge num" style={{ fontSize: '0.85rem', padding: '6px 12px' }}><Clock size={14} /> {clock(elapsed)}</span>
          {'Notification' in window && Notification.permission === 'default' && (
            <button className="btn btn-icon sm" title="Enable completion notifications" onClick={() => Notification.requestPermission()}><Bell size={16} /></button>
          )}
          <button className="btn btn-icon sm" title={prefs.sound ? 'Mute beeps' : 'Unmute beeps'} onClick={() => updatePreferences({ sound: !prefs.sound })}>{prefs.sound ? <Volume2 size={16} /> : <VolumeX size={16} />}</button>
          <button className="btn btn-icon sm" title={prefs.voice ? 'Turn off voice coach' : 'Turn on voice coach'} onClick={() => updatePreferences({ voice: !prefs.voice })}>{prefs.voice ? <Mic size={16} /> : <MicOff size={16} />}</button>
        </div>
      </div>
      <div className="mb-3">
        <div className="row-between tiny dim mb-1"><span>{s.done.length} of {totalWork} sets complete</span><span>{Math.round(progress)}%</span></div>
        <div className="bar"><span style={{ width: `${progress}%` }} /></div>
      </div>

      <div className="player">
        {/* Stage */}
        <section className={`card player-stage ${step.kind}`}>
          <div className="phase-label">
            {step.kind === 'prepare' ? 'Get ready' : isRest ? 'Rest' : `Exercise ${step.exIndex + 1} of ${plan.items.length}`}
          </div>
          <h1 style={{ fontSize: 'clamp(1.5rem, 3.5vw, 2.3rem)' }}>
            {isRest ? (nextEx ? `Next: ${nextEx.name}` : 'Almost done!') : ex.name}
          </h1>
          {isWork && (
            <div className="set-pills" aria-label={`Set ${step.set} of ${step.totalSets}`}>
              {Array.from({ length: step.totalSets }).map((_, i) => <span key={i} className={i < step.set ? 'on' : ''} />)}
            </div>
          )}

          <div className={`row${compact ? '' : ' wrap'}`} style={{ justifyContent: 'center', gap: 'clamp(12px, 4vw, 48px)', width: '100%' }}>
            <div className="figure-box player-figure" style={{ maxWidth: compact ? 150 : 300, flex: compact ? '1 1 0' : undefined }}>
              <ExerciseFigure pose={showFigureEx.pose} animate={s.status === 'running' || s.status === 'idle'} speed={isRest ? 2.4 : 1.4} color={isRest ? '#5ee7ff' : '#c6ff3d'} title={showFigureEx.name} />
            </div>
            <ProgressRing value={phasePct} size={compact ? 150 : 200} stroke={compact ? 10 : 12} color={ringColor}>
              <div>
                {isWork && step.mode === 'reps' ? (
                  <>
                    <div className="big-timer" style={{ fontSize: compact ? '2.6rem' : '3.4rem' }}>{step.reps}</div>
                    <div className="small dim">reps · {clock(s.remaining)}</div>
                  </>
                ) : (
                  <>
                    <div className={`big-timer${s.remaining <= 3.2 && s.status === 'running' ? ' pulse' : ''}`} style={{ fontSize: compact ? '2.6rem' : '3.4rem' }}>{clock(s.remaining)}</div>
                    <div className="small dim">{step.kind === 'prepare' ? 'starting in' : isRest ? 'rest' : 'hold / keep going'}</div>
                  </>
                )}
              </div>
            </ProgressRing>
          </div>

          {isWork && !compact && <p className="small muted" style={{ maxWidth: 520 }}>{ex.instructions[0]} {ex.tip && <span className="dim">· {ex.tip}</span>}</p>}
          {isRest && <p className="small muted">Breathe deeply and shake it out. {nextStep ? `Set ${nextStep.set} of ${nextStep.totalSets}` : ''}</p>}
          {step.kind === 'prepare' && <p className="small muted">{s.status === 'idle' ? 'Press start when you are ready. Sound on for beeps and voice cues.' : 'Get into position…'}</p>}

          {/* Controls */}
          <div className="player-controls mt-1">
            <button className="btn btn-icon lg" onClick={prevExercise} disabled={s.index === 0} title="Previous exercise (←)" aria-label="Previous exercise"><SkipBack size={22} /></button>
            {s.status === 'running' ? (
              <button className="btn btn-primary play-btn" onClick={pause} aria-label="Pause (space)"><Pause size={32} /></button>
            ) : (
              <button className="btn btn-primary play-btn" onClick={start} aria-label={s.status === 'idle' ? 'Start workout' : 'Resume'} style={{ boxShadow: 'var(--neon-glow)' }}><Play size={32} style={{ marginLeft: 4 }} /></button>
            )}
            <button className="btn btn-icon lg" onClick={nextExercise} title="Next exercise (→)" aria-label="Next exercise"><SkipForward size={22} /></button>
          </div>
          <div className="row wrap" style={{ justifyContent: 'center' }}>
            {s.status === 'idle' && <span className="small dim">Tip: <span className="kbd">Space</span> start/pause · <span className="kbd">←</span><span className="kbd">→</span> exercises</span>}
            {isWork && s.status !== 'idle' && <button className="btn btn-sm" onClick={completeCurrent}><Check size={15} /> Set done</button>}
            {isWork && s.status !== 'idle' && <button className="btn btn-sm" onClick={completeExercise}><CheckCheck size={15} /> Complete exercise</button>}
            {(isRest || step.kind === 'prepare') && s.status !== 'idle' && <button className="btn btn-sm" onClick={completeCurrent}><SkipForward size={15} /> Skip {isRest ? 'rest' : 'countdown'}</button>}
            {isRest && s.status !== 'idle' && <button className="btn btn-sm" onClick={() => dispatch({ type: 'addTime', seconds: 15 })}><Plus size={15} /> 15s</button>}
            {s.status !== 'idle' && <button className="btn btn-sm btn-ghost" onClick={() => setConfirm('reset')}><RotateCcw size={15} /> Reset</button>}
            {s.status !== 'idle' && <button className="btn btn-sm btn-ghost" onClick={() => setConfirm('end')}><Flag size={15} /> Finish</button>}
          </div>
        </section>

        {/* Exercise list */}
        <aside className="card">
          <div className="card-head">
            <h3>Workout plan</h3>
            <span className="tiny dim">{plan.items.length} exercises</span>
          </div>
          <div className="step-list">
            {plan.items.map((it, idx) => {
              const e = EXERCISE_MAP[it.exerciseId];
              const mine = workIdx.filter((i) => steps[i].exIndex === idx);
              const doneSets = mine.filter((i) => s.done.includes(i)).length;
              const isCurrent = step.kind !== 'prepare' && step.exIndex === idx;
              const allDone = doneSets === mine.length;
              return (
                <button key={`${it.exerciseId}-${idx}`} className={`step-row${isCurrent ? ' current' : ''}${allDone ? ' done' : ''}`} onClick={() => goto(mine[0])}>
                  <span className="check">{allDone ? <Check size={14} /> : <span className="tiny">{idx + 1}</span>}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="truncate" style={{ fontWeight: 600 }}>{e.name}</div>
                    <div className="tiny dim">{it.sets} × {it.duration != null ? `${it.duration}s` : `${it.reps} reps`} · {it.rest}s rest</div>
                  </div>
                  <span className="tiny num" style={{ color: doneSets ? 'var(--neon)' : 'var(--text-3)' }}>{doneSets}/{mine.length}</span>
                </button>
              );
            })}
          </div>
        </aside>
      </div>

      {confirm && (
        <Modal
          size="sm"
          title={confirm === 'reset' ? 'Reset workout?' : confirm === 'end' ? 'Finish workout now?' : 'Leave workout?'}
          onClose={() => setConfirm(null)}
        >
          <p className="muted">
            {confirm === 'reset' && 'The timer and all completed sets will be cleared and you’ll start again from the beginning.'}
            {confirm === 'end' && (s.done.length ? `You’ve completed ${s.done.length} of ${totalWork} sets. Your progress will be saved to history.` : 'You haven’t completed any sets yet, so nothing will be saved.')}
            {confirm === 'leave' && 'Your progress in this session will be lost. Use “Finish” instead to save what you’ve done.'}
          </p>
          <div className="row mt-3" style={{ justifyContent: 'flex-end' }}>
            <button className="btn" onClick={() => setConfirm(null)}>Keep going</button>
            {confirm === 'reset' && <button className="btn btn-danger" onClick={() => { reset(); setConfirm(null); }}><RotateCcw size={16} /> Reset</button>}
            {confirm === 'end' && <button className="btn btn-primary" onClick={() => { setConfirm(null); finish(sRef.current.done); }}><Flag size={16} /> Finish & save</button>}
            {confirm === 'leave' && <button className="btn btn-danger" onClick={() => { window.speechSynthesis?.cancel(); navigate('/'); }}>Leave without saving</button>}
          </div>
        </Modal>
      )}
      <Toasts />
    </div>
  );
}

function Summary({ plan, results, setsDone, totalWork, saved, onAgain }) {
  const navigate = useNavigate();
  const full = setsDone === totalWork;
  return (
    <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', padding: 16 }}>
      <div className="card neon" style={{ width: 'min(620px, 100%)', textAlign: 'center', padding: 'clamp(20px, 5vw, 40px)' }}>
        <div className="stat-icon" style={{ width: 72, height: 72, borderRadius: 24, margin: '0 auto 14px', boxShadow: 'var(--neon-glow)' }}><Trophy size={36} /></div>
        <div className="eyebrow">{full ? 'Workout complete' : 'Workout saved'}</div>
        <h1>{full ? 'Amazing work! 🎉' : setsDone ? 'Nice effort! 💪' : 'Session ended'}</h1>
        <p className="muted mt-1">{plan.name} · {setsDone}/{totalWork} sets</p>
        <div className="grid grid-3 mt-3" style={{ gap: 12 }}>
          <div className="card" style={{ padding: 14 }}><Clock size={18} className="neon-text" style={{ margin: '0 auto' }} /><div className="stat-value mt-1" style={{ fontSize: '1.5rem' }}>{humanDuration(results.activeSec)}</div><div className="tiny dim">active time</div></div>
          <div className="card" style={{ padding: 14 }}><Flame size={18} style={{ margin: '0 auto', color: '#ff7a3d' }} /><div className="stat-value mt-1" style={{ fontSize: '1.5rem' }}>{results.kcal}</div><div className="tiny dim">kcal (est.)</div></div>
          <div className="card" style={{ padding: 14 }}><Dumbbell size={18} style={{ margin: '0 auto', color: '#5ee7ff' }} /><div className="stat-value mt-1" style={{ fontSize: '1.5rem' }}>{results.perExercise.filter((e) => e.setsDone >= e.totalSets).length}/{plan.items.length}</div><div className="tiny dim">exercises</div></div>
        </div>
        <p className="small dim mt-2">{saved && saved !== 'none' ? 'Saved to your workout history on this device.' : 'No completed sets, so nothing was saved.'}</p>
        <div className="row wrap mt-3" style={{ justifyContent: 'center' }}>
          <button className="btn" onClick={onAgain}><RotateCcw size={16} /> Do it again</button>
          <button className="btn" onClick={() => navigate('/progress')}><BarChart3 size={16} /> View progress</button>
          <button className="btn btn-primary" onClick={() => navigate('/')}><Home size={16} /> Dashboard</button>
        </div>
      </div>
    </div>
  );
}
