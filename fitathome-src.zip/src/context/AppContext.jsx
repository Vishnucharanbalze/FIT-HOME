import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { STORAGE_KEY, SCHEMA_VERSION, createDemoState, createEmptyState, DEFAULT_PREFERENCES, DEFAULT_PROFILE } from '../data/demoData';
import { toKey } from '../utils/date';

const AppContext = createContext(null);

/** Read saved state from localStorage. First visit -> demo data so the app looks complete. */
function loadInitialState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.version === SCHEMA_VERSION) {
        return {
          ...createEmptyState(),
          ...parsed,
          profile: { ...DEFAULT_PROFILE, ...parsed.profile },
          preferences: { ...DEFAULT_PREFERENCES, ...parsed.preferences },
          water: { goalMl: 2500, logs: {}, ...parsed.water },
        };
      }
    }
  } catch (err) {
    console.warn('FitAtHome: could not read saved data, loading demo.', err);
  }
  return createDemoState();
}

const uid = (prefix = 'id') => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;

export function AppProvider({ children }) {
  const [state, setState] = useState(loadInitialState);
  const [toasts, setToasts] = useState([]);
  const [storageOk, setStorageOk] = useState(true);
  const first = useRef(true);

  // Persist every change.
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      if (!storageOk) setStorageOk(true);
    } catch (err) {
      console.error('FitAtHome: saving failed', err);
      setStorageOk(false);
    }
    first.current = false;
  }, [state]); // eslint-disable-line react-hooks/exhaustive-deps

  // Keep multiple open tabs in sync on the same device.
  useEffect(() => {
    const onStorage = (e) => {
      if (e.key === STORAGE_KEY && e.newValue) {
        try {
          setState(JSON.parse(e.newValue));
        } catch {
          /* ignore */
        }
      }
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  const toast = useCallback((message, type = 'success') => {
    const id = uid('t');
    setToasts((t) => [...t, { id, message, type }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);

  const update = useCallback((fn) => setState((s) => ({ ...s, ...fn(s) })), []);

  const actions = useMemo(
    () => ({
      toast,
      // ---- profile & preferences
      updateProfile: (patch) => update((s) => ({ profile: { ...s.profile, ...patch } })),
      updatePreferences: (patch) => update((s) => ({ preferences: { ...s.preferences, ...patch } })),

      // ---- plans
      savePlan: (plan) => {
        const id = plan.id || uid('custom');
        const clean = { ...plan, id, builtIn: false, updatedAt: new Date().toISOString() };
        if (!plan.id) clean.createdAt = new Date().toISOString();
        update((s) => {
          const exists = s.customPlans.some((p) => p.id === id);
          const customPlans = exists ? s.customPlans.map((p) => (p.id === id ? clean : p)) : [...s.customPlans, clean];
          const scheduledPlanIds = exists || !(clean.days || []).length
            ? s.scheduledPlanIds
            : Array.from(new Set([...s.scheduledPlanIds, id]));
          return { customPlans, scheduledPlanIds };
        });
        return id;
      },
      deletePlan: (id) =>
        update((s) => ({
          customPlans: s.customPlans.filter((p) => p.id !== id),
          scheduledPlanIds: s.scheduledPlanIds.filter((x) => x !== id),
        })),
      toggleSchedule: (id) =>
        update((s) => ({
          scheduledPlanIds: s.scheduledPlanIds.includes(id)
            ? s.scheduledPlanIds.filter((x) => x !== id)
            : [...s.scheduledPlanIds, id],
        })),
      setPlanDays: (id, days, isBuiltIn) =>
        update((s) =>
          isBuiltIn
            ? { planDays: { ...s.planDays, [id]: [...days].sort() } }
            : { customPlans: s.customPlans.map((p) => (p.id === id ? { ...p, days: [...days].sort() } : p)) }
        ),

      // ---- history
      addHistory: (entry) => {
        const d = new Date();
        const full = { id: uid('h'), date: d.toISOString(), dayKey: toKey(d), ...entry };
        update((s) => ({ history: [...s.history, full] }));
        return full;
      },
      deleteHistory: (id) => update((s) => ({ history: s.history.filter((h) => h.id !== id) })),

      // ---- water
      addWater: (ml) => {
        const k = toKey();
        update((s) => ({
          water: {
            ...s.water,
            logs: { ...s.water.logs, [k]: [...(s.water.logs[k] || []), { id: uid('w'), ml: Number(ml), time: new Date().toISOString() }] },
          },
        }));
      },
      removeWater: (entryId) => {
        const k = toKey();
        update((s) => {
          const list = s.water.logs[k] || [];
          const next = entryId ? list.filter((x) => x.id !== entryId) : list.slice(0, -1);
          return { water: { ...s.water, logs: { ...s.water.logs, [k]: next } } };
        });
      },
      resetWaterToday: () => {
        const k = toKey();
        update((s) => ({ water: { ...s.water, logs: { ...s.water.logs, [k]: [] } } }));
      },
      setWaterGoal: (goalMl) => update((s) => ({ water: { ...s.water, goalMl: Number(goalMl) } })),

      // ---- body measurements (BMI)
      addMeasurement: ({ heightCm, weightKg }) => {
        const d = new Date();
        const k = toKey(d);
        update((s) => ({
          profile: { ...s.profile, heightCm: Number(heightCm), weightKg: Number(weightKg) },
          measurements: [
            ...s.measurements.filter((m) => m.dayKey !== k),
            { id: uid('m'), date: d.toISOString(), dayKey: k, heightCm: Number(heightCm), weightKg: Number(weightKg) },
          ],
        }));
      },
      deleteMeasurement: (id) => update((s) => ({ measurements: s.measurements.filter((m) => m.id !== id) })),

      // ---- demo & data management
      loadDemo: () => {
        setState(createDemoState());
        toast('Demo data loaded');
      },
      clearAll: () => {
        setState(createEmptyState());
        toast('All data cleared — fresh start!');
      },
      exitDemoKeepData: () => update(() => ({ demoMode: false })),
      exportData: () => {
        const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `fitathome-backup-${toKey()}.json`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      },
      importData: async (file) => {
        const text = await file.text();
        const parsed = JSON.parse(text);
        if (!parsed || parsed.version !== SCHEMA_VERSION || !Array.isArray(parsed.history)) {
          throw new Error('This file is not a valid FitAtHome backup.');
        }
        setState({ ...createEmptyState(), ...parsed });
        toast('Backup restored');
      },
    }),
    [state, toast, update]
  );

  const value = useMemo(() => ({ state, ...actions, toasts, storageOk }), [state, actions, toasts, storageOk]);
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside <AppProvider>');
  return ctx;
}
