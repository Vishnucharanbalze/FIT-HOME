import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

/**
 * Tiny zero-dependency PWA helper.
 * After the production build it lists every file in /dist and injects that list
 * (plus a content hash used as the cache version) into dist/sw.js, so the service
 * worker can precache the whole app and run fully offline after the first visit.
 */
function swPrecachePlugin() {
  let outDir = 'dist';
  return {
    name: 'fitathome-sw-precache',
    apply: 'build',
    configResolved(config) {
      outDir = path.resolve(config.root, config.build.outDir);
    },
    closeBundle() {
      const swPath = path.join(outDir, 'sw.js');
      if (!fs.existsSync(swPath)) return;
      const files = [];
      const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
          const full = path.join(dir, entry.name);
          if (entry.isDirectory()) walk(full);
          else files.push(full);
        }
      };
      walk(outDir);
      const hash = crypto.createHash('sha1');
      const urls = files
        .filter((f) => !/(sw\.js|_redirects|\.map)$/.test(f))
        .map((f) => {
          hash.update(fs.readFileSync(f));
          return '/' + path.relative(outDir, f).split(path.sep).join('/');
        })
        .sort();
      urls.unshift('/');
      const version = hash.digest('hex').slice(0, 10);
      const sw = fs
        .readFileSync(swPath, 'utf8')
        .replace('__PRECACHE_MANIFEST__', JSON.stringify(urls))
        .replace('__CACHE_VERSION__', version);
      fs.writeFileSync(swPath, sw);
      console.log(`\n[pwa] service worker precaches ${urls.length} files (version ${version})`);
    },
  };
}

export default defineConfig({
  plugins: [react(), swPrecachePlugin()],
  server: { port: 5173, open: true },
  preview: { port: 4173 },
  build: {
    chunkSizeWarningLimit: 1200,
  },
});
